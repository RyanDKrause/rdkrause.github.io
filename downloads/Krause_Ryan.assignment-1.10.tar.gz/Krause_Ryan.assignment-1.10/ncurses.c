#include <ncurses.h>
#include <string.h>

#include "structures.h"
#include "movement.h"
#include "ncurses.h"
#include "items.h"
#include "create.h" //dice are here...
#include "combat.h" //For calculating new speed of player

#define DEBUG 0

void curses_init() {
	initscr();
	raw();
	noecho();
	curs_set(0);
	keypad(stdscr, TRUE);
	start_color();
	
	init_pair(COLOR_BLACK, COLOR_BLACK, COLOR_BLACK);
	init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
	init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
	init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
	init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
	init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
	init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);
	init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);

}

void end_curses() {
	curs_set(1);
	clear();
	endwin();
}

void get_input(dungeon *d, character *ch) {

	//nodelay(stdscr, TRUE);
	int input;
	int valid = 0;
	while(!valid) {
		input = getch();
		valid = 1;
		switch (input) {
		
			case 'S':
			//case 's':
				//d->monsters_array[0].alive = 0;
				d->game_on = 0;
				break;	
				
			case '7':
			case 'y':
				player_move_true(d, ch, 7);
			break;
			
			case '8':
			case 'k':
				player_move_true(d, ch, 8);
			break;
			
			case '9':
			case 'u':
				player_move_true(d, ch, 9);
			break;
			
			case '6':
			case 'l':
				player_move_true(d, ch, 6);
			break;
			
			case '3':
			case 'n':
				player_move_true(d, ch, 3);
			break;
			
			case '2':
			case 'j':
				player_move_true(d, ch, 2);
			break;
			
			case '1':
			case 'b':
				player_move_true(d, ch, 1);
			break;
			
			case '4':
			case 'h':
				player_move_true(d, ch, 4);
			break;
			
			case 'L':
				lookaround(d);
			break;
			
			case '<':
				//Go up stairs
				if (d->empty_space[d->monsters_array[0].current_pos.x][d->monsters_array[0].current_pos.y] == 3) {
					//this works
					d->game_on = 2;
				}
			break;
			
			case '>':
				//Go down stairs
				if (d->empty_space[d->monsters_array[0].current_pos.x][d->monsters_array[0].current_pos.y] == 4) {
					//this works too!
					d->game_on = 2;				
				}
			break;
			
			case 'q':
				d->game_on = 2;
			break;
			
			case ' ': //space
			break; //nothing happens!
			
			case 'z':
				d->monsters_array[0].alive = 0;
				break;
	
			case 'i':
			case 'w':
			case 'W':
			case 't':
			case 'T':
			case 'd':
			case 'D':
			case 'x':
			case 'X':
				show_equipment(d);
				print_dungeon_section(d);
				valid = 0; //we use escape to get out of equipment, so the player doesn't waste a move equipping.
				break;
				
			default:
				valid = 0;
				break;
		
		}
	}
	
}

void lookaround(dungeon *d) {

	int section_x = ((d->monsters_array[0].current_pos.x)/20) - 2;
	int section_y = ((d->monsters_array[0].current_pos.y)/8) - 1;
	
	if (section_x > 4) { //right bound checking
		section_x = 4;
	}
	if (section_y > 9) { //down bound checking
		section_y = 9;
	}
	if (section_y < 0) { //up bound checking
		section_y = 0;
	}
	if (section_x < 0) { //left bound checking
		section_x = 0;
	}
	
	int input = 69; //Heehee
	
	while (input != 27) { //27 is escape key code
		
		input = getch();
		switch (input) {
		
			case '8':
			case 'k':
				section_y -= 1;
			break;
			
			case '6':
			case 'l':
				section_x += 1;
			break;
			
			case '2':
			case 'j':
				section_y += 1;
			break;
			
			case '4':
			case 'h':
				section_x -= 1;
			break;
			
			case '7':
			case 'y':
				section_x -= 1;
				section_y -= 1;
			break;
			
			case '9':
			case 'u':
				section_x += 1;
				section_y -= 1;
			break;
			
			case '3':
			case 'n':
				section_x += 1;
				section_y += 1;
			break;
			
			case '1':
			case 'b':
				section_x -= 1;
				section_y += 1;
			break;
			
		}
	
	
		if (section_x > 4) { //right bound checking
			section_x = 4;
		}
		if (section_y > 9) { //down bound checking
			section_y = 9;
		}
		if (section_y < 0) { //up bound checking
			section_y = 0;
		}
		if (section_x < 0) { //left bound checking
			section_x = 0;
		}
	
		int i,j,k;	
		
		//int id = -1;
		for (j = section_y*8; j < section_y*8 + 24; j++) {
			for (i = section_x*20; i < section_x*20 + 80; i++) {
				char space;
				int my_color = -1;
				int items_count = 0;
				if (d->floor_plan[i][j] == START_ROCK) {
					//printf("M"); //shouldn't be shown
					space = 'M';
				}
				else if (d->floor_plan[i][j] == EMPTY_SPACE) {
					//printf(".");
					space = '.';
				}
				else if (d->floor_plan[i][j] == PLAYER_SPACE) {
					//printf("@");
					space = '@';
				}
				else if (d->floor_plan[i][j] == BUFFER_SPACE) {
					//printf("b"); //for testing purposes, will never show up
					space = 'b';
				}
				else if (d->floor_plan[i][j] == IMPOSSIBLE_ROCK) {
					//printf("X"); //again, testing.
					//printf("#");
					space = '#';
				}
				else if (d->floor_plan[i][j] == MONSTER_SPACE) {	
					space = '.';
				}
				else if (d->floor_plan[i][j] == STAIR_UP) {
					//printf("M");
					space = '<';
				}
				else if (d->floor_plan[i][j] == STAIR_DOWN) {
					//printf("M");
					space = '>';
				}
				else {
					//printf("#"); //reasons.
					space = '#';
				}
				
				//put items down
				for (k = 0; k < d->items_count; k++) {
					if (i == d->items_array[k].current_pos.x && j == d->items_array[k].current_pos.y && d->items_array[k].visible) {
						space = items[convert_item_type(d->items_array[k].type)];
						my_color = colors[convert_color_type(d->items_array[k].color)];	
						items_count++;
					}		
				}	
					
				//put monsters down
				for (k = 1; k < d->monsters_count; k++) {
					if (i == d->monsters_array[k].current_pos.x && j == d->monsters_array[k].current_pos.y && d->monsters_array[k].alive) {
						space = d->monsters_array[k].symbol;				
						my_color = colors[convert_color_type(d->monsters_array[k].color)];
						break;
					}		
				}			
				if (my_color != -1) {
					attron(COLOR_PAIR(my_color));
				}
				
				if (items_count > 1) {
					space = '&'; //if we have more than one item, then we make a stack symbol. 
					//It'll be the color of the last item read in the array. 
				}
				
				mvaddch(j-section_y*8, i-section_x*20, space);
				
				if (my_color != -1) {
					attroff(COLOR_PAIR(my_color));
				}
			}
			//printf("\n");
		}		

	
	mvprintw(29, 0, "Lookout mode is activated");
	mvprintw(30, 0, "Current X Section: %d", section_x);
	mvprintw(31, 0, "Current Y Section: %d", section_y);
	
	refresh();
	}
	
}

void print_dungeon_section(dungeon *d) {
	
	/*
	each section is 20 * 8
	1 | 2 | 3 | 4 | 5 | 6 | 7 | 8
	9 | 10| 11| 12| 13| 14| 15| 16
	17| 18| 19| 20| 21| 22| 23| 24
	25| 26| 27| 28| 29| 30| 31| 32
	
	33| 34| 35| 36| 37| 38| 39| 40
	41| 42| 43| 44| 45| 46| 47| 48
	49| 50| 51| 52| 53| 54| 55| 56
	57| 58| 59| 60| 61| 62| 63| 64
	
	The window will be 4*3 "sections."
	*/
	
	
	//Integer division is wonderful here. 
	int section_x = ((d->monsters_array[0].current_pos.x)/20) - 2;
	int section_y = ((d->monsters_array[0].current_pos.y)/8) - 1;
	
	if (section_x > 4) { //right bound checking
		section_x = 4;
	}
	if (section_y > 9) { //down bound checking
		section_y = 9;
	}
	if (section_y < 0) { //up bound checking
		section_y = 0;
	}
	if (section_x < 0) { //left bound checking
		section_x = 0;
	}
		
	//clear();


	if (DEBUG) {
	mvprintw(29, 0, "DEBUG STUFF:");
	mvprintw(30, 0, "X Section: %d", section_x);
	mvprintw(31, 0, "Y Section: %d", section_y);
	mvprintw(32, 0, "Current X: %d", d->monsters_array[0].current_pos.x);
	mvprintw(33, 0, "Current Y: %d", d->monsters_array[0].current_pos.y);
	mvprintw(34, 0, "Empty_Space: %d", d->empty_space[d->monsters_array[0].current_pos.x][d->monsters_array[0].current_pos.y]);
	mvprintw(35, 0, "Room Count: %d", d->room_count);
	mvprintw(36, 0, "Game on: %d", d->game_on);
	mvprintw(37, 0, "Monsters Left: %d", d->monsters_count);
	mvprintw(38, 0, "Monster X: %d", d->monsters_array[5].current_pos.x);
	mvprintw(39, 0, "Monster Y: %d", d->monsters_array[5].current_pos.y);
	mvprintw(40, 0, "Smart: %d", d->monsters_array[4].smart);
	mvprintw(41, 0, "Item X: %d", d->items_array[5].current_pos.x);
	mvprintw(42, 0, "Item Y: %d", d->items_array[5].current_pos.y);
	mvprintw(43, 0, "Current Player Speed: %d", d->monsters_array[0].speed);
	
	}
	int i,j,k;	
	for (j = section_y*8; j < section_y*8 + 24; j++) {
		for (i = section_x*20; i < section_x*20 + 80; i++) {
			char space;
			int my_color = -1;
			int items_count = 0;
			if (d->floor_plan[i][j] == START_ROCK) {
				//printf("M"); //shouldn't be shown
				space = 'M';
			}
			else if (d->floor_plan[i][j] == EMPTY_SPACE) {
				//printf(".");
				space = '.';
			}
			else if (d->floor_plan[i][j] == BUFFER_SPACE) {
				//printf("b"); //for testing purposes, will never show up
				space = 'b';
			}
			else if (d->floor_plan[i][j] == IMPOSSIBLE_ROCK) {
				//printf("X"); //again, testing.
				//printf("#");
				space = '#';
			}
			else if (d->floor_plan[i][j] == MONSTER_SPACE) {	
				
				space = '.'; //legacy code, see below
					
			}
			else if (d->floor_plan[i][j] == STAIR_UP) {
				//printf("M");
				space = '<';
				
			}
			else if (d->floor_plan[i][j] == STAIR_DOWN) {
				//printf("M");
				space = '>';
			}			
			else {
				//printf("#"); //reasons.
				space = '#';
			}
			
			//put items down
			for (k = 0; k < d->items_count; k++) {
				if (i == d->items_array[k].current_pos.x && j == d->items_array[k].current_pos.y && d->items_array[k].visible) {
					space = items[convert_item_type(d->items_array[k].type)];
					my_color = colors[convert_color_type(d->items_array[k].color)];	
					items_count++;
				}		
			}	
				
			//put monsters down
			for (k = 1; k < d->monsters_count; k++) {
				if (i == d->monsters_array[k].current_pos.x && j == d->monsters_array[k].current_pos.y && d->monsters_array[k].alive) {
					space = d->monsters_array[k].symbol;				
					my_color = colors[convert_color_type(d->monsters_array[k].color)];
					break;
				}		
			}		
			
			//player gets priority always
			if (d->floor_plan[i][j] == PLAYER_SPACE) {
				space = '@';
			}
			
			if (my_color != -1) {
				attron(COLOR_PAIR(my_color));
			}
			
			if (items_count > 1) {
				space = '&'; //if we have more than one item, then we make a stack symbol. 
				//It'll be the color of the last item read in the array. 
			}
				
				
			mvaddch(j-section_y*8, i-section_x*20, space);
					
			if (my_color != -1) {
				attroff(COLOR_PAIR(my_color));
			}
		}
		//printf("\n");
	}
	refresh();


}


void print_dungeon_curses(dungeon *d) {

	clear(); //clear screen before redrawing
	
	int i,j;	
		for (j = 0; j < HEIGHT; j++) {
			for (i = 0; i < WIDTH; i++) {
				char space;
				if (d->floor_plan[i][j] == START_ROCK) {
					//printf("M"); //shouldn't be shown
					space = 'M';
				}
				else if (d->floor_plan[i][j] == EMPTY_SPACE) {
					//printf(".");
					space = '.';
				}
				else if (d->floor_plan[i][j] == PLAYER_SPACE) {
					//printf("@");
					space = '@';
				}
				else if (d->floor_plan[i][j] == BUFFER_SPACE) {
					//printf("b"); //for testing purposes, will never show up
					space = 'b';
				}
				else if (d->floor_plan[i][j] == IMPOSSIBLE_ROCK) {
					//printf("X"); //again, testing.
					//printf("#");
					space = '#';
				}
				else if (d->floor_plan[i][j] == MONSTER_SPACE) {
					//printf("M");
					space = 'M';
				}
				else if (d->floor_plan[i][j] == STAIR_UP) {
					//printf("M");
					space = '<';
				}
				else if (d->floor_plan[i][j] == STAIR_DOWN) {
					//printf("M");
					space = '>';
				}
				else {
					//printf("#"); //reasons.
					space = '#';
				}
				
				mvaddch(j, i, space);
			}
			//printf("\n");
		}
		refresh();
}

color_types_t convert_color_type(char* str) {

	if (strcmp(str, "BLACK") == 0) {
		return BLACK;
	}
	else if (strcmp(str, "BLUE") == 0) {
		return BLUE;
	}
	else if (strcmp(str, "CYAN") == 0) {
		return CYAN;
	}
	else if (strcmp(str, "GREEN") == 0) {
		return GREEN;
	}
	else if (strcmp(str, "MAGENTA") == 0) {
		return MAGENTA;
	}
	else if (strcmp(str, "RED") == 0) {
		return RED;
	}
	else if (strcmp(str, "WHITE") == 0) {
		return WHITE;
	}
	else if (strcmp(str, "YELLOW") == 0) {
		return YELLOW;
	}
	else {
		return BLACK;
	}
}


void show_equipment(dungeon *d) {
	
	int choice = 0;
	
	int input = 69; //Heehee
	
	while (input != 27) { //27 is escape key code
		
		clear(); //let's start over for now, "new window"
		
		
		mvprintw(2+choice, 1, "-->"); //shows the current selected choice
			
		mvprintw(0, 5, "Equipment Screen:");
		mvprintw(1, 5, "Slot\t\t Type            Name            \t Damage\t Speed\t Health\t Dodge\t Defense ");
		
		item current_item; //I don't want multiple variables...
		
		//WEAPON
		current_item = d->monsters_array[0].inventory.weapon;
		mvprintw(2, 5, "WEAPON:\t\t Weapon %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//OFFHAND
		current_item = d->monsters_array[0].inventory.offhand;
		mvprintw(3, 5, "OFFHAND:\t\t Offhand %25s \t% d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//RANGED
		current_item = d->monsters_array[0].inventory.ranged;
		mvprintw(4, 5, "RANGED:\t\t Ranged %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//ARMOR
		current_item = d->monsters_array[0].inventory.armor;
		mvprintw(5, 5, "ARMOR:\t\t Armor %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//HELMET
		current_item = d->monsters_array[0].inventory.helmet;
		mvprintw(6, 5, "HELMET:\t\t Helmet %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//CLOAK
		current_item = d->monsters_array[0].inventory.cloak;
		mvprintw(7, 5, "CLOAK:\t\t Cloak %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//GLOVES
		current_item = d->monsters_array[0].inventory.gloves;
		mvprintw(8, 5, "GLOVES:\t\t Gloves %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BOOTS
		current_item = d->monsters_array[0].inventory.boots;
		mvprintw(9, 5, "BOOTS:\t\t Boots %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//AMULET
		current_item = d->monsters_array[0].inventory.amulet;
		mvprintw(10, 5, "AMULET:\t\t Amulet %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//LIGHT
		current_item = d->monsters_array[0].inventory.light;
		mvprintw(11, 5, "LIGHT:\t\t Light %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//RING1
		current_item = d->monsters_array[0].inventory.ring1;
		mvprintw(12, 5, "LEFT RING:\t\t Ring %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//RING2
		current_item = d->monsters_array[0].inventory.ring2;
		mvprintw(13, 5, "RIGHT RING:\t Ring %25s \t %d-%d \t %d \t %d \t %d \t %d", current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 0
		current_item = d->monsters_array[0].inventory.carrying[0];
		mvprintw(14, 5, "Backpack 0: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 1
		current_item = d->monsters_array[0].inventory.carrying[1];
		mvprintw(15, 5, "Backpack 1: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 2
		current_item = d->monsters_array[0].inventory.carrying[2];
		mvprintw(16, 5, "Backpack 2: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 3
		current_item = d->monsters_array[0].inventory.carrying[3];
		mvprintw(17, 5, "Backpack 3: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 4
		current_item = d->monsters_array[0].inventory.carrying[4];
		mvprintw(18, 5, "Backpack 4: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 5
		current_item = d->monsters_array[0].inventory.carrying[5];
		mvprintw(19, 5, "Backpack 5: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 6
		current_item = d->monsters_array[0].inventory.carrying[6];
		mvprintw(20, 5, "Backpack 6: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 7
		current_item = d->monsters_array[0].inventory.carrying[7];
		mvprintw(21, 5, "Backpack 7: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 8
		current_item = d->monsters_array[0].inventory.carrying[8];
		mvprintw(22, 5, "Backpack 8: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//BACKPACK 9
		current_item = d->monsters_array[0].inventory.carrying[9];
		mvprintw(23, 5, "Backpack 9: \t%s\t %20s \t\t %d-%d \t %d \t %d \t %d \t %d", current_item.type, current_item.name, low_roll(current_item.damage), high_roll(current_item.damage), current_item.speed, current_item.hit, current_item.dodge, current_item.defense);
		
		//mvprintw(30, 5 ,"CARRYING ITEMS %d", d->monsters_array[0].inventory.items_carrying);
		mvprintw(26, 5, "Use up and down to move the cursor");
		mvprintw(27, 5, "Press E to equip (or dequip)");
		mvprintw(28, 5, "Press D to drop");
		mvprintw(29, 5, "Press X to destroy");
		mvprintw(30, 5, "Press Escape to exit this screen");
		mvprintw(31, 5, "Professor said this was fine. :) ");
		
		//mvprintw(35, 5, "Choice number %d", choice); 
		
		refresh();	
		
		input = getch();
		switch (input) {
			case '8':
			case 'k':
				choice--;
				break;
				
			case '2':
			case 'j':
				choice++;
				break;
				
			case 'e':
			case 'E':
				if (choice > 11) { //carrying area
				
					item temp = {};
					char* type = d->monsters_array[0].inventory.carrying[choice-12].type;
					
					if (strcmp(type, "WEAPON") == 0) {
						temp = d->monsters_array[0].inventory.weapon;
						d->monsters_array[0].inventory.weapon = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "OFFHAND") == 0) {
						temp = d->monsters_array[0].inventory.offhand;
						d->monsters_array[0].inventory.offhand = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "RANGED") == 0) {
						temp = d->monsters_array[0].inventory.ranged;
						d->monsters_array[0].inventory.ranged = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "ARMOR") == 0) {
						temp = d->monsters_array[0].inventory.armor;
						d->monsters_array[0].inventory.armor = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "HELMET") == 0) {
						temp = d->monsters_array[0].inventory.helmet;
						d->monsters_array[0].inventory.helmet = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "CLOAK") == 0) {
						temp = d->monsters_array[0].inventory.cloak;
						d->monsters_array[0].inventory.cloak = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "GLOVES") == 0) {
						temp = d->monsters_array[0].inventory.gloves;
						d->monsters_array[0].inventory.gloves = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "BOOTS") == 0) {
						temp = d->monsters_array[0].inventory.boots;
						d->monsters_array[0].inventory.boots = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "AMULET") == 0) {
						temp = d->monsters_array[0].inventory.amulet;
						d->monsters_array[0].inventory.amulet = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "LIGHT") == 0) {
						temp = d->monsters_array[0].inventory.light;
						d->monsters_array[0].inventory.light = d->monsters_array[0].inventory.carrying[choice-12];
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
					}
					
					if (strcmp(type, "RING") == 0) {
						
						temp = d->monsters_array[0].inventory.ring1;
						if (temp.name[0] == '\0') { //Then there is nothing in the first ring slot
						
							d->monsters_array[0].inventory.ring1 = d->monsters_array[0].inventory.carrying[choice-12];
							d->monsters_array[0].inventory.carrying[choice-12] = temp;
						}
						
						else if (d->monsters_array[0].inventory.ring2.name == NULL) { //ring slot 2 is open
							d->monsters_array[0].inventory.ring2 = d->monsters_array[0].inventory.carrying[choice-12];
							d->monsters_array[0].inventory.carrying[choice-12] = temp;
						}
						
						else { //just swap the items in slot 1
							d->monsters_array[0].inventory.ring1 = d->monsters_array[0].inventory.carrying[choice-12];
							d->monsters_array[0].inventory.carrying[choice-12] = temp;
						}
					}
					

					
					if (temp.name[0] == '\0') { //there was nothing to swap, so there's a free backpack space now
						d->monsters_array[0].inventory.items_carrying--;
						organize_backpack(d); //if there's a random slot open, fill it!
					}
					
				}
				
				else { //un-equipping items
					if (d->monsters_array[0].inventory.items_carrying < 10) { //make sure we have room to store this item in my backsack
						
						item temp = {};
						switch (choice) {
							case 0:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.weapon.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.weapon;
									d->monsters_array[0].inventory.weapon = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 1:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.offhand.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.offhand;
									d->monsters_array[0].inventory.offhand = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
							
							case 2:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.ranged.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.ranged;
									d->monsters_array[0].inventory.ranged = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 3:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.armor.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.armor;
									d->monsters_array[0].inventory.armor = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 4:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.helmet.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.helmet;
									d->monsters_array[0].inventory.helmet = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 5:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.cloak.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.cloak;
									d->monsters_array[0].inventory.cloak = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 6:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.gloves.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.gloves;
									d->monsters_array[0].inventory.gloves = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 7:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.boots.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.boots;
									d->monsters_array[0].inventory.boots = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 8:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.amulet.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.amulet;
									d->monsters_array[0].inventory.amulet = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 9:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.light.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.light;
									d->monsters_array[0].inventory.light = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 10:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.ring1.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.ring1;
									d->monsters_array[0].inventory.ring1 = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
								
							case 11:
								temp = d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying];
								if (d->monsters_array[0].inventory.ring2.name[0] != '\0') { //Don't unequip a null item...
									d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->monsters_array[0].inventory.ring2;
									d->monsters_array[0].inventory.ring2 = temp;
									if (temp.name[0] == '\0') { //there was nothing to swap, so we added an item to the sack
										d->monsters_array[0].inventory.items_carrying++;
									}
								}
								break;
									
						}
					
					}
				
				}
				
				break;
				
			
			//destroying items
			case 'x':
			case 'X':
				if (choice > 11) { //carrying area
				
					item temp = {};
					if (d->monsters_array[0].inventory.carrying[choice-12].name[0] != '\0') { //make sure there's actually something to remove
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
						d->monsters_array[0].inventory.items_carrying--;
						organize_backpack(d); //if there's a random slot open now, fill it!
					}
					
				}
				
				else { //equipped area
					
						
					item temp; //just a null item.
					//the beauty of this is even if there is no item equipped, nothing will happen!
					switch (choice) {
						case 0:
							d->monsters_array[0].inventory.weapon = temp;
							break;
						case 1:
							d->monsters_array[0].inventory.offhand = temp;
							break;
						case 2:
							d->monsters_array[0].inventory.ranged = temp;
							break;
						case 3:
							d->monsters_array[0].inventory.armor = temp;
							break;
						case 4:
							d->monsters_array[0].inventory.helmet = temp;
							break;
						case 5:
							d->monsters_array[0].inventory.cloak = temp;							
							break;
						case 6:
							d->monsters_array[0].inventory.gloves = temp;
							break;
						case 7:
							d->monsters_array[0].inventory.boots = temp;
							break;
						case 8:
							d->monsters_array[0].inventory.amulet = temp;
							break;
						case 9:
							d->monsters_array[0].inventory.light = temp;
							break;
						case 10:
							d->monsters_array[0].inventory.ring1 = temp;
							break;
						case 11:
							d->monsters_array[0].inventory.ring2 = temp;
							break;	
						}
									
				}
				
				break;
				
			//Dropping items
			case 'd':
			case 'D':
				if (choice > 11) { //carrying area
				
					item temp = {};
					if (d->monsters_array[0].inventory.carrying[choice-12].name[0] != '\0') { //make sure there's actually something to remove
						d->monsters_array[0].inventory.carrying[choice-12].current_pos.x = d->monsters_array[0].current_pos.x;
						d->monsters_array[0].inventory.carrying[choice-12].current_pos.y = d->monsters_array[0].current_pos.y;
						d->monsters_array[0].inventory.carrying[choice-12].visible = 1;
						
						d->items_array[d->items_count] = d->monsters_array[0].inventory.carrying[choice-12];
						d->items_count++;
						
						d->monsters_array[0].inventory.carrying[choice-12] = temp;
						d->monsters_array[0].inventory.items_carrying--;
						organize_backpack(d); //if there's a random slot open now, fill it!
					}
					
				}
				
				else { //equipped area
					
						
					item temp; //just a null item.
					switch (choice) {
						case 0:
							if (d->monsters_array[0].inventory.weapon.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.weapon.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.weapon.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.weapon.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.weapon;
								d->items_count++;
								d->monsters_array[0].inventory.weapon = temp;
							}
							break;
						case 1:
							if (d->monsters_array[0].inventory.offhand.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.offhand.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.offhand.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.offhand.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.offhand;
								d->items_count++;
								d->monsters_array[0].inventory.offhand = temp;
							}
							break;
						case 2:
							if (d->monsters_array[0].inventory.ranged.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.ranged.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.ranged.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.ranged.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.ranged;
								d->items_count++;
								d->monsters_array[0].inventory.ranged = temp;
							}
							break;
						case 3:
							if (d->monsters_array[0].inventory.armor.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.armor.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.armor.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.armor.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.armor;
								d->items_count++;
								d->monsters_array[0].inventory.armor = temp;
							}
							break;
						case 4:
							if (d->monsters_array[0].inventory.helmet.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.helmet.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.helmet.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.helmet.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.helmet;
								d->items_count++;
								d->monsters_array[0].inventory.helmet = temp;
							}
							break;
						case 5:
							if (d->monsters_array[0].inventory.cloak.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.cloak.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.cloak.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.cloak.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.cloak;
								d->items_count++;
								d->monsters_array[0].inventory.cloak = temp;
							}
							break;
						case 6:
							if (d->monsters_array[0].inventory.gloves.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.gloves.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.gloves.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.gloves.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.gloves;
								d->items_count++;
								d->monsters_array[0].inventory.gloves = temp;
							}
							break;
						case 7:
							if (d->monsters_array[0].inventory.boots.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.boots.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.boots.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.boots.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.boots;
								d->items_count++;
								d->monsters_array[0].inventory.boots = temp;
							}
							break;
						case 8:
							if (d->monsters_array[0].inventory.amulet.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.amulet.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.amulet.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.amulet.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.amulet;
								d->items_count++;
								d->monsters_array[0].inventory.amulet = temp;
							}
							break;
						case 9:
							if (d->monsters_array[0].inventory.light.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.light.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.light.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.light.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.light;
								d->items_count++;
								d->monsters_array[0].inventory.light = temp;
							}
							break;
						case 10:
							if (d->monsters_array[0].inventory.ring1.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.ring1.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.ring1.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.ring1.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.ring1;
								d->items_count++;
								d->monsters_array[0].inventory.ring1 = temp;
							}
							break;
						case 11:
							if (d->monsters_array[0].inventory.ring2.name[0] != '\0') { //make sure there's actually something to remove
								d->monsters_array[0].inventory.ring2.current_pos.x = d->monsters_array[0].current_pos.x;
								d->monsters_array[0].inventory.ring2.current_pos.y = d->monsters_array[0].current_pos.y;
								d->monsters_array[0].inventory.ring2.visible = 1;
								d->items_array[d->items_count] = d->monsters_array[0].inventory.ring2;
								d->items_count++;
								d->monsters_array[0].inventory.ring2 = temp;
							}
							break;	
						}
									
				}
				
				break;
		}
	
		if (choice < 0) {
			choice = 11 + d->monsters_array[0].inventory.items_carrying; //max choice
		}
		if (choice > d->monsters_array[0].inventory.items_carrying + 11) {
			choice = 0; //min choice
		}
	}
	
	clear();
	
	calculate_speed(d); //update the player speed now that we have new equipment. 
	
}

int organize_backpack(dungeon *d) {
	
	int i, j;
	
	//for (i = 0; i < d->monsters_array[0].inventory.items_carrying; i++) {
	for (i = 0; i < 10; i++) {
	
	
		if (d->monsters_array[0].inventory.carrying[i].name[0] == '\0') { //NO ITEM HERE
			for (j = i+1; j < 9; j++) { //9 cause we do a j+1 thing...
				if (d->monsters_array[0].inventory.carrying[j].name[0] != '\0') { //THERE IS AN ITEM HERE
					d->monsters_array[0].inventory.carrying[i] = d->monsters_array[0].inventory.carrying[j];
					for (j = j; j < 9; j++) { //I feel bad doing this.... It's 2:30AM and I'm tired and can't think.
						d->monsters_array[0].inventory.carrying[j] = d->monsters_array[0].inventory.carrying[j+1];
					}
					break;
				}
			}
		}
	}
	
	for (i = d->monsters_array[0].inventory.items_carrying; i < 10; i++) {
			item bad = {};
			d->monsters_array[0].inventory.carrying[i] = bad;
			
	}

	return 0;

}
