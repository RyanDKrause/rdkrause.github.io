#include <ncurses.h>
#include <string.h>

#include "structures.h"
#include "ncurses.h"
#include "items.h"
#include "create.h" //dice are here...
#include "combat.h"

int calculate_speed(dungeon *d) {

	int new_speed = 20; //base speed
	
	
	if (d->monsters_array[0].inventory.weapon.name[0] != '\0') { //there is an item in the weapon slot
		new_speed += d->monsters_array[0].inventory.weapon.speed;
	}
	
	if (d->monsters_array[0].inventory.offhand.name[0] != '\0') { //there is an item in the offhand slot
		new_speed += d->monsters_array[0].inventory.offhand.speed;
	}
	
	if (d->monsters_array[0].inventory.ranged.name[0] != '\0') { //there is an item in the ranged slot
		new_speed += d->monsters_array[0].inventory.ranged.speed;
	}
	
	if (d->monsters_array[0].inventory.armor.name[0] != '\0') { //there is an item in the armor slot
		new_speed += d->monsters_array[0].inventory.armor.speed;
	}
	
	if (d->monsters_array[0].inventory.helmet.name[0] != '\0') { //there is an item in the helmet slot
		new_speed += d->monsters_array[0].inventory.helmet.speed;
	}
	
	if (d->monsters_array[0].inventory.cloak.name[0] != '\0') { //there is an item in the cloak slot
		new_speed += d->monsters_array[0].inventory.cloak.speed;
	}
	
	if (d->monsters_array[0].inventory.gloves.name[0] != '\0') { //there is an item in the gloves slot
		new_speed += d->monsters_array[0].inventory.gloves.speed;
	}
	
	if (d->monsters_array[0].inventory.boots.name[0] != '\0') { //there is an item in the boots slot
		new_speed += d->monsters_array[0].inventory.boots.speed;
	}
	
	if (d->monsters_array[0].inventory.amulet.name[0] != '\0') { //there is an item in the amulet slot
		new_speed += d->monsters_array[0].inventory.amulet.speed;
	}
	
	if (d->monsters_array[0].inventory.light.name[0] != '\0') { //there is an item in the light slot
		new_speed += d->monsters_array[0].inventory.light.speed;
	}
	
	if (d->monsters_array[0].inventory.ring1.name[0] != '\0') { //there is an item in the ring1 slot
		new_speed += d->monsters_array[0].inventory.ring1.speed;
	}
	
	if (d->monsters_array[0].inventory.ring2.name[0] != '\0') { //there is an item in the ring2 slot
		new_speed += d->monsters_array[0].inventory.ring2.speed;
	}
	
	d->monsters_array[0].speed = new_speed;
	
	return 0;
}

int player_battle(dungeon *d, int monster_id) {

	int player_damage = 0;
	
	if (d->monsters_array[0].inventory.weapon.name[0] != '\0') { //there is an item in the weapon slot
		player_damage += roll_damage(d->monsters_array[0].inventory.weapon.damage);
	}
	else {
		player_damage += roll_damage(d->monsters_array[0].damage); //bare haaaaands damage
	}
	
	if (d->monsters_array[0].inventory.offhand.name[0] != '\0') { //there is an item in the offhand slot
		player_damage += roll_damage(d->monsters_array[0].inventory.offhand.damage);
	}
	
	if (d->monsters_array[0].inventory.ranged.name[0] != '\0') { //there is an item in the ranged slot
		player_damage += roll_damage(d->monsters_array[0].inventory.ranged.damage);
	}
	
	if (d->monsters_array[0].inventory.armor.name[0] != '\0') { //there is an item in the armor slot
		player_damage += roll_damage(d->monsters_array[0].inventory.armor.damage);
	}
	
	if (d->monsters_array[0].inventory.helmet.name[0] != '\0') { //there is an item in the helmet slot
		player_damage += roll_damage(d->monsters_array[0].inventory.helmet.damage);
	}
	
	if (d->monsters_array[0].inventory.cloak.name[0] != '\0') { //there is an item in the cloak slot
		player_damage += roll_damage(d->monsters_array[0].inventory.cloak.damage);
	}
	
	if (d->monsters_array[0].inventory.gloves.name[0] != '\0') { //there is an item in the gloves slot
		player_damage += roll_damage(d->monsters_array[0].inventory.gloves.damage);
	}
	
	if (d->monsters_array[0].inventory.boots.name[0] != '\0') { //there is an item in the boots slot
		player_damage += roll_damage(d->monsters_array[0].inventory.boots.damage);
	}
	
	if (d->monsters_array[0].inventory.amulet.name[0] != '\0') { //there is an item in the amulet slot
		player_damage += roll_damage(d->monsters_array[0].inventory.amulet.damage);
	}
	
	if (d->monsters_array[0].inventory.light.name[0] != '\0') { //there is an item in the light slot
		player_damage += roll_damage(d->monsters_array[0].inventory.light.damage);
	}
	
	if (d->monsters_array[0].inventory.ring1.name[0] != '\0') { //there is an item in the ring1 slot
		player_damage += roll_damage(d->monsters_array[0].inventory.ring1.damage);
	}
	
	if (d->monsters_array[0].inventory.ring2.name[0] != '\0') { //there is an item in the ring2 slot
		player_damage += roll_damage(d->monsters_array[0].inventory.ring2.damage);
	}
	
	d->monsters_array[monster_id].hitpoints -= player_damage;
	
	
	clear();
	//Killllllllll
	if (d->monsters_array[monster_id].hitpoints <= 0) {
		d->monsters_array[monster_id].alive = 0;	
		mvprintw(25, 0, "You did %d damage, you killed %s!", player_damage, d->monsters_array[monster_id].name);
		
		d->floor_plan[d->monsters_array[monster_id].current_pos.x][d->monsters_array[monster_id].current_pos.y] = EMPTY_SPACE;
	}
	else {
		mvprintw(25, 0, "You did %d damage, %s has %d health remaining", player_damage, d->monsters_array[monster_id].name, d->monsters_array[monster_id].hitpoints);
	}
	
	refresh();
	return 0;

}

int monster_battle(dungeon *d, int monster_id) {
	
	int monster_damage = roll_damage(d->monsters_array[monster_id].damage);
	
	d->monsters_array[0].hitpoints -= monster_damage;
	
	if (d->monsters_array[0].hitpoints <= 0) {
		d->monsters_array[0].alive = 0;
	}
	else {
		mvprintw(26, 0, "%s did %d damage to you, you have %d health remaining", d->monsters_array[monster_id].name, monster_damage, d->monsters_array[0].hitpoints);
	}
	refresh();
	
	
	return 0;

}