#ifndef FILES_H
#define FILES_H

int save_file(dungeon *d);
int load_file(dungeon *d);
int delete_file();

#endif
