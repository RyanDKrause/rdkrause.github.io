#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h> //floor()

#include <unistd.h> //for sleep function

#include "structures.h" //holds structures needed for dungeons/rooms
#include "create.h" //where the dungeon setup is done
#include "files.h" //where we save and load dungeons
#include "movement.h" //how the monsters/players move

#include "pQueue.h" //priority queue and Dijkstras currently
#include "pQueue2.h" //priority for monsters turn

#include "ncurses.h" //for user input/writing to console
 
#include "npc.h" //Holds monster definition CPP classes
#include "items.h" //Holds item definition CPP Classes
 
#define ITEMS_TO_GENERATE 100

int main(int argc, char* argv[]) {

	srand(time(NULL)); 
		
	curses_init();	
	
	dungeon d;
	pQueue2 turnQ;
	
	parse_monsters(&d);
	//print_monsters(&d);
	parse_items(&d);
	//print_items(&d);
	
	//return 0;
		
	d.game_on = 3;
	
	int start_game = 1;
	
	character player;
	
	while(d.game_on) {
		int num_monsters = 10;
		
		initialize_dungeon(&d); //set up dungeon and everything in it
		
		int i, j;
		
		for (j = 0; j < HEIGHT; j++) { //I initialize this again because I can.
			for (i = 0; i < WIDTH; i++) {
				d.floor_plan[i][j] = START_ROCK;
				d.dist_plan[i][j] = 0;
				d.empty_space[i][j] = 0;
			}
		}
		
		//if it's first start up, load a file if there is one.
		if (start_game) {
			if (load_file(&d) == 1) { //loading didn't work for some reason...
				create_dungeon(&d);		
				
				int start_x = d.rooms_array[10].start_x + d.rooms_array[10].room_width/2;
				int start_y = d.rooms_array[10].start_y + d.rooms_array[10].room_height/2;
				
				
				
				initialize_pQueue2(&turnQ);
				
				// created player stuff 
				character player;
				
				
				player.speed = 20;
				player.next_turn = floor(100/player.speed);
				player.player = 1;
				player.smart = 0;
				player.tele = 0; 
				player.current_pos.x = start_x;
				player.current_pos.y = start_y;
				player.alive = 1;
				dice_c base = {0, 1, 4};
				player.damage = base;
				player.hitpoints = 100000;
				
				d.monsters_array[0] = player;
				
				d.monsters_array[0].inventory.items_carrying = 0;
				
				add_pQueue2(&turnQ, player);
				d.floor_plan[start_x][start_y] = PLAYER_SPACE;
				
				//creating all other monsters
				for (i = 1; i < num_monsters; i++) {
					
					
					generate_monster(&d);
					
					//update position of the monster cause I didn't do it in the above function...
					int randnum = rand() % d.room_count;
					d.monsters_array[i].current_pos.x = d.rooms_array[randnum].start_x + rand() % d.rooms_array[randnum].room_width;
					d.monsters_array[i].current_pos.y = d.rooms_array[randnum].start_y + rand() % d.rooms_array[randnum].room_height;
					
					//That's it! We made it!
					
					
					//Now add it to the queue and make it show up on the map
					add_pQueue2(&turnQ, d.monsters_array[i]);
					d.floor_plan[d.monsters_array[i].current_pos.x][d.monsters_array[i].current_pos.y] = MONSTER_SPACE;
					
					
					
					generate_items(&d, ITEMS_TO_GENERATE);
				}

			//end character creation stuff
			
			}
			else {
				initialize_pQueue2(&turnQ);
				for (i = 0; i < d.monsters_count; i++) {
					add_pQueue2(&turnQ, d.monsters_array[i]);
				}
			}
			start_game = 0;
			
		}
		else {
			create_dungeon(&d);
			
			int start_x = d.rooms_array[10].start_x + d.rooms_array[10].room_width/2;
			int start_y = d.rooms_array[10].start_y + d.rooms_array[10].room_height/2;
			
			
			
			initialize_pQueue2(&turnQ);
			
			// created player stuff 
			
			//player needs a new position though!
			player.current_pos.x = start_x;
			player.current_pos.y = start_y;
			//player.alive = 1;
			
			d.monsters_array[0] = player;
			
			add_pQueue2(&turnQ, player);
			d.floor_plan[start_x][start_y] = PLAYER_SPACE;
			
			//creating all other monsters
			for (i = 1; i < num_monsters; i++) {
				
				
				generate_monster(&d);
					
				//update position of the monster cause I didn't do it in the above function...
				int randnum = rand() % d.room_count;
				d.monsters_array[i].current_pos.x = d.rooms_array[randnum].start_x + rand() % d.rooms_array[randnum].room_width;
				d.monsters_array[i].current_pos.y = d.rooms_array[randnum].start_y + rand() % d.rooms_array[randnum].room_height;
				
				//That's it! We made it!
				
				//Now add it to the queue and make it show up on the map
				add_pQueue2(&turnQ, d.monsters_array[i]);
				d.floor_plan[d.monsters_array[i].current_pos.x][d.monsters_array[i].current_pos.y] = MONSTER_SPACE;
				
			}

			//end character creation stuff
			
			generate_items(&d, ITEMS_TO_GENERATE);
		}
		
		character tempchar;
		
		
		d.game_on = 1;
		//game_start!
		while (d.monsters_array[0].alive == 1 && d.game_on == 1) {
		
			
			remove_pQueue2(&turnQ, &tempchar);
			tempchar.next_turn += floor(100/tempchar.speed);
	
			if (tempchar.player) {
				tempchar.alive = 1;
				
				
				print_dungeon_section(&d);
				get_input(&d, &tempchar);
				tempchar.speed = d.monsters_array[0].speed; //just to be on the safe side?

				 
			}
			else {
				int id;
				for (i = 1; i < MAX_MONSTERS; i++) {
					if (tempchar.current_pos.x == d.monsters_array[i].current_pos.x && tempchar.current_pos.y == d.monsters_array[i].current_pos.y) {
						id = i;
					}		
				}
				
				if (d.monsters_array[id].alive) {
					monster_move(&d, id);
					square next = monster_move(&d, id);
					tempchar.current_pos.x = next.x;
					tempchar.current_pos.y = next.y;
				}
				else {
					tempchar.alive = 0;
				}
			
			}
			
			
			add_pQueue2(&turnQ, tempchar);		
		}
		
		if (d.monsters_array[0].alive == 0) {
			while (turnQ.size != 0) {
				remove_pQueue2(&turnQ, &tempchar); //remove stuff 
			}
			break;
		}
		
		if (d.game_on != 1 || d.game_on == 0) {
			while (turnQ.size != 0) {
				remove_pQueue2(&turnQ, &tempchar); //remove stuff 
			}
		}
		
		player = d.monsters_array[0]; //save the player for the next level
	}

	end_curses();
	
	if (d.monsters_array[0].alive == 0) {
		printf("\nLol you died.");
		if (delete_file() == 0) {
			printf("\nFile deleted successfully.\n");
		}
	}
	
	if (d.game_on == 0) {
		//printf("\nRage quit?");
		
		if (save_file(&d) == 0) {
			printf("\nGame Saved!\n");
		}	
	}
	
	destroy_monsters(&d);
	destroy_items(&d);
	//free_characters_and_inventory(&d);
	
	return 0;
}


