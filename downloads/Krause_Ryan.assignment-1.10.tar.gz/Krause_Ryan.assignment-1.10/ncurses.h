#ifndef NCURSES_H
#define NCURSES_H

#include <ncurses.h>

typedef enum {
	BLACK,
	BLUE, 
	CYAN,
	GREEN,
	MAGENTA,
	RED,
	WHITE,
	YELLOW
} color_types_t;

static const int colors[] = {
	COLOR_BLACK,
	COLOR_BLUE, 
	COLOR_CYAN,
	COLOR_GREEN,
	COLOR_MAGENTA,
	COLOR_RED,
	COLOR_WHITE,
	COLOR_YELLOW
};

void print_dungeon_curses(dungeon *d);
void end_curses();
void curses_init();
void get_input(dungeon *d, character *ch);
void print_dungeon_section(dungeon *d);
void lookaround(dungeon *d);
color_types_t convert_color_type(char* str);
void show_equipment(dungeon *d);
int organize_backpack(dungeon *d);
#endif
