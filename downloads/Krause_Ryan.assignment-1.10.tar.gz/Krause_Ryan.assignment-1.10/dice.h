#ifndef DICE_H
#define DICE_H

#include "structures.h"

# ifdef __cplusplus

class dice {
private:
	int base;
	int num_dices;
	int sides;
public:
	dice() : base(0), num_dices(0), sides(0)
	{
	}
	
	inline void set (int b, int num_d, int s) {
		this->base = b;
		this->num_dices = num_d;
		this->sides = s;
	}
	inline void set_base(int b) {
		this->base = b;
	}
	inline void set_number(int num_d) {
		this->num_dices = num_d;
	}
	inline void set_sides(int s) {
		this->sides = s;
	}
	inline int get_base() const {
		return this->base;
	}
	inline int get_number() const {
		return this->num_dices;
	}
	inline int get_sides() const {
		return this->sides;
	}
	
	int roll();
	
	
};

extern "C" {
int roll(const dice &d);
dice_c convert_to_c(const dice &d);
}
#endif

#endif