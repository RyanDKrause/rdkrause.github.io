#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <endian.h>
#include <stdint.h> //uint8_t

#include "structures.h"

int delete_file() {
	char *path; // Absolute path to the file
	char *home; // The name of our home directory
	char *file; // The name of the file
	
	home = getenv("HOME");
	file = ".rlg229/dungeon";
	path = malloc(strlen(home) + strlen(file) + 2 ); //2 is for the NULL and internal /	
	sprintf(path, "%s/%s", home, file);
	int ret;
	ret = remove(path);
	free(path);
	
	return ret;  //0 on successful delete
	
}


int load_file(dungeon *d) {


	char *path; // Absolute path to the file
	char *home; // The name of our home directory
	char *file; // The name of the file
	FILE *f;
	
	home = getenv("HOME");
	//home = "/home/rdkrause";
	file = ".rlg229/dungeon";
	//file = "dungeon";
	path = malloc(strlen(home) + strlen(file) + 2 ); //2 is for the NULL and internal /
	//path = malloc(strlen(file) + 2);
	/*
	if (!path) {
		fprintf(stderr, "malloc failed!\n");
		return 1;
	}*/
	
	sprintf(path, "%s/%s", home, file);
	
	f = fopen(path, "r"); //open to read
	
	free(path);
	//f = fopen(file, "r");

	/*
	if (!f) {
		perror("File not found to load");
		exit(1);
	}
	*/
	if (!f) {
		perror("There is no save file on this system.");
		return 1;
	}
	
	char file_name[10];
	fread(&file_name, 6, 1, f);
	
	if (strcmp(file_name, "RLG229") != 0) {
		perror("We aren't reading the right type of file?");
		return 1;
	}
	
	unsigned int version;
	fread(&version, 4, 1, f);
	version = be32toh(version); 
	
	unsigned int file_size;// = 61455*8 + 32*d->room_count - 14; //we need 32 more bits for every room in the dungeon, then subtract 14 cause reasons.
	fread(&file_size, 4, 1, f);
	file_size = be32toh(file_size);
	
	unsigned int user_block;
	fread(&user_block, 4, 1, f);
	user_block = be32toh(user_block);
	
	//the cheating way to find the number of rooms in the dungeon... 
	//int rooms = file_size + 14 - 61455;
	//rooms = rooms/4;
	//d->room_count = rooms;
	
	int i, j;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			
			int first_byte = 0;
			int second_byte = 0;
			int third_byte = 0;
			unsigned int fourth_byte = 0;
			int fifth_byte = 0;
			
			
			fread(&first_byte, 1, 1, f);
			fread(&second_byte, 1, 1, f);
			fread(&third_byte, 1, 1, f);
			fread(&fourth_byte, 1, 1, f);	
			fread(&fifth_byte, 1, 1, f);	
									
			if (first_byte == 0) {
			//this space is empty!
				d->empty_space[i][j] = 0;
			}
			if (second_byte != 0) {
			//this space is part of a room!
				d->empty_space[i][j] = 1;
			}
			if (third_byte != 0) { //I COULD check to see if this was already made a room... but we'll trust the map makers.
			//this space is a corridor!
				d->empty_space[i][j] = 2;
			}
			
			d->floor_plan[i][j] = fourth_byte;
			
			if (fifth_byte == 1) { //should check if not a room/corridor tile, but w/e. 
				d->empty_space[i][j] = 4; //down stairs
				d->floor_plan[i][j] = STAIR_DOWN;
			}
			if (fifth_byte == 2) {
				d->empty_space[i][j] = 3; //up stairs
				d->floor_plan[i][j] = STAIR_UP;
			}
		}
	}
	
	unsigned int room_count;// = d->room_count;
	
	fread(&room_count, 2, 1, f);
	
	//printf("%d\n", room_count);
	room_count = be16toh(room_count);
	//printf("%d\n", room_count);
	//room_count = room_count/256; //this works fine?
	//room_count = room_count/256;
	
	d->room_count = room_count;
	
	
	for (i = 0; i < d->room_count; i++) {
		int first_room_byte = 0;
		int second_room_byte = 0;
		int third_room_byte = 0;
		int fourth_room_byte = 0;

		fread(&first_room_byte, 1, 1, f);
		fread(&second_room_byte, 1, 1, f);
		fread(&third_room_byte, 1, 1, f);
		fread(&fourth_room_byte, 1, 1, f);	
		
		d->rooms_array[i].start_x = first_room_byte;
		d->rooms_array[i].start_y = second_room_byte;
		d->rooms_array[i].room_width = third_room_byte;
		d->rooms_array[i].room_height = fourth_room_byte;
		
		//make sure that everything is being set up correctly!
		//printf("%d, %d, %d, %d\n", d->rooms_array[i].start_x, d->rooms_array[i].start_y, d->rooms_array[i].room_width, d->rooms_array[i].room_height);
		
		
	}
	
	//I don't know what to do with this right now. 
	unsigned int player_x;
	uint8_t player_y;
	fread(&player_x, 1, 1, f);
	fread(&player_y, 1, 1, f);
	
	unsigned int game_turn;
	fread(&game_turn, 4, 1, f);
	game_turn = be32toh(game_turn);
	
	
	character player;
	player.current_pos.x = player_x;
	player.current_pos.y = player_y;
	player.speed = 10;
	player.next_turn = game_turn;
	player.player = 1;
	player.alive = 1;
	player.smart = 0;
	player.tele = 0;
	
	d->monsters_array[0] = player;
	
	d->floor_plan[player_x][player_y] = PLAYER_SPACE;
	
	unsigned int monster_seq;
	fread(&monster_seq, 4, 1, f);
	monster_seq = be32toh(monster_seq);
	
	unsigned int npc_count;
	fread(&npc_count, 2, 1, f);
	npc_count = be16toh(npc_count);
	//npc_count = npc_count/256/256;
	
	d->monsters_count = npc_count;
	
	for (i = 0; i < npc_count; i++) {
		char graphic; //1
		unsigned int pos_x; //1
		uint8_t pos_y; //1
		unsigned int speed; //1
		uint8_t smart; //1
		unsigned int tele; //1
		unsigned int last_player_x; //1
		unsigned int last_player_y; //1
		unsigned int id_num; //4
		unsigned int next_turn; //4
		unsigned int alive; //1
		unsigned int junk; //19
		
		
		fread(&graphic, 1, 1, f);
		fread(&pos_x, 1, 1, f);
		fread(&pos_y, 1, 1, f);
		fread(&speed, 1, 1, f);
		fread(&smart, 1, 1, f);
		fread(&tele, 1, 1, f);
		fread(&last_player_x, 1, 1, f);
		fread(&last_player_y, 1, 1, f);
		fread(&id_num, 4, 1, f);
		fread(&next_turn, 4, 1, f);
		fread(&alive, 1, 1, f);
		fread(&junk, 19, 1, f);
		
		
		id_num = be32toh(id_num);
		next_turn = be32toh(next_turn);
		
		character new_guy;
		
		new_guy.current_pos.x = pos_x;
		new_guy.current_pos.y = pos_y;
		new_guy.speed = speed;
		new_guy.next_turn = next_turn;
			
		/*
		if (smart) {
			new_guy.smart = 1;
		}
		else {
			new_guy.smart = 0;
		}
		*/
		new_guy.smart = smart;
		
		if (tele) {
			new_guy.tele = 1;
		}
		else {
			new_guy.tele = 0;
		}
		
		new_guy.player = 0;		
		new_guy.alive = alive;
		
		
		d->monsters_array[i+1] = new_guy;
		
		if (alive) {
			d->floor_plan[pos_x][pos_y] = MONSTER_SPACE;
		}
			
	
	}
	
	
	fclose(f);
  
	return 0;
}

int save_file(dungeon *d) {
	
	char *path; // Absolute path to the file
	char *home; // The name of our home directory
	char *file; // The name of the file
	FILE *f;
	
	//home = "/home/rdkrause";
	home = getenv("HOME"); //I'M SORRY THIS ISN'T WORKING?!?!?!
	file = ".rlg229/dungeon";
	//file = "dungeon";
	
	path = malloc(strlen(home) + strlen(file) + 2 ); //2 is for the NULL and internal /
	if (!path) {
		fprintf(stderr, "malloc failed!\n");
		return 1;
	}
	
	sprintf(path, "%s/%s", home, file);
	
	f = fopen(path, "w"); //open to write
	
	//f  = fopen(file, "w");
	if (!f) {
		perror("File not found to load");
		return 1;
	}
  
  
	char file_name[] = "RLG229";
	fwrite(file_name, 6, 1, f);
	
	unsigned int version = 1;
	version = htobe32(version);
	fwrite(&version, 4, 1, f);
	
	unsigned int file_size = 76818 + 32*d->room_count + 2 + 4 + 4 + 2 + 36*(d->monsters_count-1) - 14; //Math happens
	file_size = htobe32(file_size);
	fwrite(&file_size, 4, 1, f);
	
	unsigned int user_block = 0;
	user_block = htobe32(user_block);
	fwrite(&user_block, 4, 1, f);
	
	int i, j;
	for (j = 0; j < d->height; j++) {
		for (i = 0; i < d->width; i++) {
			
			int first_byte = 0;
			int second_byte = 0;
			int third_byte = 0;
			unsigned int fourth_byte = 0;
			int fifth_byte = 0;
			
			if (d->empty_space[i][j] != 0) {
			//this space is empty!
				first_byte = 1;
			}
			if (d->empty_space[i][j] == 1) {
			//this space is part of a room!
				second_byte = 1;
			}
			if (d->empty_space[i][j] == 2) {
			//this space is a corridor!
				third_byte = 1;
			}
			
			//stairs up
			if (d->empty_space[i][j] == 3) {
				fifth_byte = 2;
			}
			
			//stairs down
			if (d->empty_space[i][j] == 4) {
				fifth_byte = 1;
			}
			fourth_byte = d->floor_plan[i][j];
			
			fwrite(&first_byte, 1, 1, f);
			fwrite(&second_byte, 1, 1, f);
			fwrite(&third_byte, 1, 1, f);
			fwrite(&fourth_byte, 1, 1, f);	
			fwrite(&fifth_byte, 1, 1, f);
		}
	}
	
	unsigned int room_count = d->room_count;
	//room_count *= 256;
	room_count = htobe16(room_count);
	fwrite(&room_count, 2, 1, f);
	
	for (i = 0; i < d->room_count; i++) {
		int first_byte = 0;
		int second_byte = 0;
		int third_byte = 0;
		int fourth_byte = 0;
		
		first_byte = d->rooms_array[i].start_x;
		second_byte = d->rooms_array[i].start_y;
		third_byte = d->rooms_array[i].room_width;
		fourth_byte = d->rooms_array[i].room_height;
		
		fwrite(&first_byte, 1, 1, f);
		fwrite(&second_byte, 1, 1, f);
		fwrite(&third_byte, 1, 1, f);
		fwrite(&fourth_byte, 1, 1, f);	
		
	}
  
	unsigned int player_x = d->monsters_array[0].current_pos.x;
	uint8_t player_y = d->monsters_array[0].current_pos.y;
	fwrite(&player_x, 1, 1, f);
	fwrite(&player_y, 1, 1, f);
	
	unsigned int game_turn = d->monsters_array[0].next_turn;
	game_turn = htobe32(game_turn);
	fwrite(&game_turn, 4, 1, f);
	  
	unsigned int monster_seq = 0;
	monster_seq = htobe32(monster_seq);
	fwrite(&monster_seq, 4, 1, f);
	
	
	unsigned int npc_count = d->monsters_count;
	//npc_count = npc_count*256*256;
	npc_count = htobe16(npc_count);
	fwrite(&npc_count, 2, 1, f);
	
	
	for (i = 0; i < d->monsters_count; i++) {
		
		character old_guy = d->monsters_array[i+1];
		
		char graphic = 0; //1
		unsigned int pos_x = old_guy.current_pos.x; //1
		uint8_t pos_y = old_guy.current_pos.y; //1
		unsigned int speed = old_guy.speed; //1	
		unsigned int smart = old_guy.smart; //1
		
		unsigned int tele = old_guy.tele; //1
		unsigned int last_player_x = 255; //1
		unsigned int last_player_y = 255; //1
		unsigned int id_num = i+1; //4
		unsigned int next_turn = old_guy.next_turn; //4
		unsigned int alive = old_guy.alive; //1
		unsigned int junk = 0; //19
		
		id_num = htobe32(id_num);
		next_turn = htobe32(next_turn);
		
		fwrite(&graphic, 1, 1, f);
		fwrite(&pos_x, 1, 1, f);
		fwrite(&pos_y, 1, 1, f);
		fwrite(&speed, 1, 1, f);
		fwrite(&smart, 1, 1, f);
		fwrite(&tele, 1, 1, f);
		fwrite(&last_player_x, 1, 1, f);
		fwrite(&last_player_y, 1, 1, f);
		fwrite(&id_num, 4, 1, f);
		fwrite(&next_turn, 4, 1, f);
		fwrite(&alive, 1, 1, f);
		fwrite(&junk, 19, 1, f);
		
		
	}
	
	
	fclose(f);
	return 0;
}