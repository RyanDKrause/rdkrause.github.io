#ifndef ITEM_H
#define ITEM_H

#include "structures.h"
#include "dice.h"

typedef enum {
	INVALID,
	WEAPON,
	OFFHAND,
	RANGED,
	ARMOR,
	HELMET,
	CLOAK,
	GLOVES,
	BOOTS,
	RING,
	AMULET,
	LIGHT,
	SCROLL,
	BOOK,
	FLASK,
	GOLD,
	AMMUNITION,
	FOOD,
	WAND,
	CONTAINER,
	STACK
} item_types_t;

static const char items[] = {
	'*',
	'|',
	')',
	'}',
	'[',
	']',
	'(',
	'{',
	'\\',
	'=',
	'"',
	'_',
	'~',
	'?',
	'!',
	'$',
	'/',
	',',
	'-',
	'%',
	'&'
};
/*
static const items_lookup items[] = {
	{[INVALID] = '*'},
	{[WEAPON] = '|'},
	{[OFFHAND] = ')'},
	{[RANGED] = '}'},
	{[ARMOR] = '['},
	{[HELMET] = ']'},
	{[CLOAK] = '('},
	{[GLOVES] = '{'},
	{[BOOTS] = '\\'},
	{[RING] = '='},
	{[AMULET] = '"'},
	{[LIGHT] = '_'},
	{[SCROLL] = '~'},
	{[BOOK] = '?'},
	{[FLASK] = '!'},
	{[GOLD] = '$'},
	{[AMMUNITION] = '/'},
	{[FOOD] = ','},
	{[WAND] = '-'},
	{[CONTAINER] = '%'},
	{[STACK] = '&'}
};
*/

# ifdef __cplusplus
extern "C" {
# endif

//unsigned long hash(const char *str); //already in npc.h
int parse_items(dungeon *d);
int print_items(dungeon *d);
int destroy_items(dungeon *d);
int generate_items(dungeon *d, int count);
item_types_t convert_item_type(char* str);
# ifdef __cplusplus
}

class Item {
private:

	string name, description, color, type;
	dice speed, damage, hit, dodge, defense, weight, attr, value;
	
	
public:

	Item() : name(), description(), color(), type(), speed(), damage(), 
			hit(), dodge(), defense(), weight(), attr(), value()
	{
	}
	
	void set(const string &name, const string &description,
			const string &color, const string &type, const dice &speed, const dice &damage, 
			const dice &hit, const dice &dodge, const dice &defense, const dice &weight,
			const dice &attr, const dice &value);

			
	inline void print() {
		cout << name << endl;
		cout << description;// << endl;
		cout << type << endl;	
		cout << color << endl;	
		cout << hit.get_base() << "+" << hit.get_number() << "d" << hit.get_sides() << endl;	
		cout << damage.get_base() << "+" << damage.get_number() << "d" << damage.get_sides() << endl;	
		cout << dodge.get_base() << "+" << dodge.get_number() << "d" << dodge.get_sides() << endl;	
		cout << defense.get_base() << "+" << defense.get_number() << "d" << defense.get_sides() << endl;	
		cout << weight.get_base() << "+" << weight.get_number() << "d" << weight.get_sides() << endl;	
		cout << speed.get_base() << "+" << speed.get_number() << "d" << speed.get_sides() << endl;		
		cout << attr.get_base() << "+" << attr.get_number() << "d" << attr.get_sides() << endl;	
		cout << value.get_base() << "+" << value.get_number() << "d" << value.get_sides() << endl;	
		cout << endl;
		
		
	}
	
	inline item create_item() {
		item temp;
		
		//free(temp.name);
		//temp.name = (char *) malloc(sizeof(char) * (name.length() + 1));
		strcpy(temp.name, this->name.c_str());
	
		//free(temp.description);
		//temp.description = (char *) malloc(sizeof(char) * (description.length() + 1));
		//strcpy(temp.description, this->description.c_str());
	
		//free(temp.color);
		//temp.color = (char *) malloc(sizeof(char) * (color.length() + 1));
		strcpy(temp.color, this->color.c_str());
		
		//free(temp.type);
		//temp.type = (char *) malloc(sizeof(char) * (type.length() + 1));
		strcpy(temp.type, this->type.c_str());
		
		temp.speed = roll(this->speed);
		temp.hit = roll(this->hit);
		temp.dodge = roll(this->dodge);
		temp.defense = roll(this->defense);
		temp.weight = roll(this->weight);
		temp.attr = roll(this->attr);
		temp.value = roll(this->value);
		
		temp.damage = convert_to_c(this->damage); //get rid of C++ class to C struct
	
		return temp;
	}	
		
};

# endif



#endif
