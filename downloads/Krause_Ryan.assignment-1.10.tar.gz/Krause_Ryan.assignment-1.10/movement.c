#include <stdio.h>
#include <stdlib.h>

#include "structures.h"
#include "pQueue.h" //my Dijkstra's is in here...
#include "combat.h" //so monsters and the player can fight


void player_move_true(dungeon *d, character *ch, int direction) {
	
	int tempX = d->monsters_array[0].current_pos.x;
	int tempY = d->monsters_array[0].current_pos.y;
	
	d->floor_plan[tempX][tempY] = EMPTY_SPACE;
	
	if (d->empty_space[tempX][tempY] == 3) {
		d->floor_plan[tempX][tempY] = STAIR_UP;
	}
	if (d->empty_space[tempX][tempY] == 4) {
		d->floor_plan[tempX][tempY] = STAIR_DOWN;
	}
	
	switch (direction) {
		case 1:
			if (tempX > 2 && tempY < HEIGHT - 2) {
				tempX -= 1; //down left
				tempY += 1;
			}
		break;
		
		case 2:	
			if (tempY < HEIGHT - 2) {
				tempY += 1; //down
			}
		break;
		
		case 3:	
			if (tempX < WIDTH - 2 && tempY < HEIGHT - 2) {
				tempX += 1; //down right
				tempY += 1;
			}
		break;	
		
		case 4:	
			if (tempX > 2) {
				tempX -= 1; //left
			}
		break;
		
		case 6:	
			if (tempX < WIDTH - 2) {
				tempX += 1; //right
			}
		break;
		
		case 7:	
			if (tempX > 2 && tempY > 2) {
				tempX -= 1; //up left
				tempY -= 1;
			}
		break;
			
		case 8:	
			if (tempY > 2) {
				tempY -= 1; //up
			}
		break;
		
		case 9:	
			if (tempX < WIDTH - 2 && tempY > 2) {
				tempX += 1; //up right
				tempY -= 1;
			}
		break;
	
	}
	
	
	if (d->floor_plan[tempX][tempY] == EMPTY_SPACE || d->floor_plan[tempX][tempY] == STAIR_UP || d->floor_plan[tempX][tempY] == STAIR_DOWN) {
		
		//since there was no monster, we can move there. 
		d->monsters_array[0].current_pos.x = tempX;
		d->monsters_array[0].current_pos.y = tempY;	
		
		int i;
		//check for items
		for (i = 0; i < d->items_count; i++) {
			if (tempX == d->items_array[i].current_pos.x && tempY == d->items_array[i].current_pos.y && d->items_array[i].visible) {
				if (d->monsters_array[0].inventory.items_carrying < 10) {
					d->items_array[i].visible = 0;
					d->monsters_array[0].inventory.carrying[d->monsters_array[0].inventory.items_carrying] = d->items_array[i];
					d->monsters_array[0].inventory.items_carrying++;
					//d->items_count--;
				}
			}		
		}
		
		d->floor_plan[tempX][tempY] = PLAYER_SPACE;
	}
	
	//if there is a monster, attack it!
	else if (d->floor_plan[tempX][tempY] == MONSTER_SPACE) {
		int i;
		for (i = 1; i < d->monsters_count; i++) {
			if (tempX == d->monsters_array[i].current_pos.x && tempY == d->monsters_array[i].current_pos.y && d->monsters_array[i].alive) {
				//d->monsters_array[i].alive = 0;
				player_battle(d, i);
				//d->monsters_count--;
			}		
		}
	
		d->floor_plan[d->monsters_array[0].current_pos.x][d->monsters_array[0].current_pos.y] = PLAYER_SPACE;
	
	}
	/*
	else if (d->floor_plan[tempX][tempY] == MONSTER_SPACE) {
		//KILL THE MONSTER!
		ch->current_pos.x = tempX;
		ch->current_pos.y = tempY;	
		
		
		
		
		d->floor_plan[tempX][tempY] = PLAYER_SPACE;
	}
	*/
	else {
		d->floor_plan[d->monsters_array[0].current_pos.x][d->monsters_array[0].current_pos.y] = PLAYER_SPACE; //undo that deletion
	}
	
}




square player_move(dungeon *d, int id) {

	square position;
	
	int thing = 1+(rand() % 7);
	
	int tempX = d->monsters_array[id].current_pos.x;
	int tempY = d->monsters_array[id].current_pos.y;
	
	position.x = tempX;
	position.y = tempY;
	
	d->floor_plan[tempX][tempY] = EMPTY_SPACE;
	
	if (d->empty_space[tempX][tempY] == 3) {
		d->floor_plan[tempX][tempY] = STAIR_UP;
	}
	if (d->empty_space[tempX][tempY] == 4) {
		d->floor_plan[tempX][tempY] = STAIR_DOWN;
	}
	
	switch (thing) {
		case 1:	
			if (tempX < WIDTH - 2) {
				tempX += 1; //right
			}
			break;
		case 2:	
			if (tempX > 2) {
				tempX -= 1; //left
			}
			break;
		case 3:	
			if (tempY < HEIGHT - 2) {
				tempY += 1; //down
			}
			break;
		case 4:	
			if (tempY > 2) {
				tempY -= 1; //up
			}
			break;
		case 5:	
			if (tempX < WIDTH - 2 && tempY < HEIGHT - 2) {
				tempX += 1; //down right
				tempY += 1;
			}
			break;
		case 6:	
			if (tempX < WIDTH - 2 && tempY > 2) {
				tempX += 1; //up right
				tempY -= 1;
			}
			break;
		case 7:
			if (tempX > 2 && tempY < HEIGHT - 2) {
				tempX -= 1; //down left
				tempY += 1;
			}
			break;
		case 8:	
			if (tempX > 2 && tempY > 2) {
				tempX -= 1; //up left
				tempY -= 1;
			}
			break;
	}
	
	if (d->floor_plan[tempX][tempY] == EMPTY_SPACE) {
		d->monsters_array[id].current_pos.x = tempX;
		d->monsters_array[id].current_pos.y = tempY;	
		
		position.x = tempX;
		position.y = tempY;
		
		if (d->monsters_array[id].player) {
			d->floor_plan[tempX][tempY] = PLAYER_SPACE;
		}
		else {
			d->floor_plan[tempX][tempY] = MONSTER_SPACE;
		}
	}
	else if ( d->floor_plan[tempX][tempY] == PLAYER_SPACE) {
		
		monster_battle(d, id);
		
		/*int i;
		for (i = 1; i < d->monsters_count; i++) {
			if (ch->current_pos.x == d->monsters_array[i].current_pos.x && ch->current_pos.y == d->monsters_array[i].current_pos.y) {
				monster_battle(d, i);
				return;
			}		
		}*/
	}
	else {
		/*
		if (ch.player) {
			d->floor_plan[tempX2][tempY2] = PLAYER_SPACE;
		}
		else {
			d->floor_plan[tempX2][tempY2] = MONSTER_SPACE;
		}
		*/
		player_move(d, id); //if they couldn't move, try again until they can!
	}
	
	return position;
}

square monster_move(dungeon *d, int id) {
	
	//character current_monster = d->monsters_array[id];
	square position;
	
	position.x = d->monsters_array[id].current_pos.x;
	position.y = d->monsters_array[id].current_pos.y;
	
	if (d->monsters_array[id].smart) {
		if (d->monsters_array[id].tele) {
			//smart and telepathic
			//Do dijkstra's with current player position	
			 
			square next = bad_Dijkstra(d, d->monsters_array[id].current_pos.x, d->monsters_array[id].current_pos.y, d->monsters_array[0].current_pos.x, d->monsters_array[0].current_pos.y);
			 
			 
			if (d->floor_plan[next.x][next.y] == EMPTY_SPACE) {
				d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = EMPTY_SPACE;
				 
				d->monsters_array[id].current_pos.x = next.x;
				d->monsters_array[id].current_pos.y = next.y;
				 
				position.x = next.x;
				position.y = next.y;
				
				
				d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = MONSTER_SPACE;
			}
			
			else if (d->floor_plan[next.x][next.y] == PLAYER_SPACE) {
				monster_battle(d, id);
			}
			//printf("Moved\n");
		 
		 
		}
		else {
			//do dijkstra's with start position of player?
			
			int i;
			int player_room = 10;
			int monster_room = 0;
			for (i = 0; i < d->room_count; i++) {
				room tempRoom = d->rooms_array[i];
				
				if (d->monsters_array[id].current_pos.x > tempRoom.start_x && d->monsters_array[id].current_pos.x < tempRoom.start_x + tempRoom.room_width &&
					d->monsters_array[id].current_pos.y > tempRoom.start_y && d->monsters_array[id].current_pos.y < tempRoom.start_y + tempRoom.room_height) {
					monster_room = i;					
				}
				
				if (d->monsters_array[0].current_pos.x > tempRoom.start_x && d->monsters_array[0].current_pos.x < tempRoom.start_x + tempRoom.room_width &&
					d->monsters_array[0].current_pos.y > tempRoom.start_y && d->monsters_array[0].current_pos.y < tempRoom.start_y + tempRoom.room_height) {
					player_room = i;					
				}
			
			}
			
			if (player_room == monster_room) {
				square next = bad_Dijkstra(d, d->monsters_array[id].current_pos.x, d->monsters_array[id].current_pos.y, d->monsters_array[0].current_pos.x, d->monsters_array[0].current_pos.y);
				 
				if (d->floor_plan[next.x][next.y] == EMPTY_SPACE) {
					d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = EMPTY_SPACE;
					 
					d->monsters_array[id].current_pos.x = next.x;
					d->monsters_array[id].current_pos.y = next.y;
					 
					position.x = next.x;
					position.y = next.y;
					
					d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = MONSTER_SPACE;
				}
				else if (d->floor_plan[next.x][next.y] == PLAYER_SPACE) {
					monster_battle(d, id);
				}
				 
			}
			else {
				player_move(d, id); //lol I'm drunk now.
			}
			
		}
		
	}	
	else {
		if (d->monsters_array[id].tele) {
			//move towards the player position, will probs get stuck in corner.
			int playerX = d->monsters_array[0].current_pos.x;
			int playerY = d->monsters_array[0].current_pos.y;
			
			int tempX = d->monsters_array[id].current_pos.x;
			int tempY = d->monsters_array[id].current_pos.y;
			
			
			if (tempX < playerX && (d->floor_plan[tempX+1][tempY] == EMPTY_SPACE || d->floor_plan[tempX+1][tempY] == PLAYER_SPACE)) {
				tempX += 1;
			}
			else if (tempX > playerX && (d->floor_plan[tempX-1][tempY] == EMPTY_SPACE || d->floor_plan[tempX-1][tempY] == PLAYER_SPACE)) {
				tempX -= 1;
			}
			
			else if (tempY < playerY && (d->floor_plan[tempX][tempY+1] == EMPTY_SPACE || d->floor_plan[tempX][tempY+1] == PLAYER_SPACE)) {
				tempY += 1;
			}
			else if (tempY > playerY && (d->floor_plan[tempX][tempY-1] == EMPTY_SPACE || d->floor_plan[tempX][tempY-1] == PLAYER_SPACE)) {
				tempY -= 1;
			}
			
			if (d->floor_plan[tempX][tempY] == EMPTY_SPACE) {
			
				d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = EMPTY_SPACE;
				if (d->empty_space[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] == 3) {
					d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = STAIR_UP;
				}
				if (d->empty_space[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] == 4) {
					d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = STAIR_DOWN;
				}
				d->monsters_array[id].current_pos.x = tempX;
				d->monsters_array[id].current_pos.y = tempY;
				d->floor_plan[d->monsters_array[id].current_pos.x][d->monsters_array[id].current_pos.y] = MONSTER_SPACE;
			}
			
			else if (d->floor_plan[tempX][tempY] == PLAYER_SPACE) {
				monster_battle(d, id);
			}
		}
		else {
			player_move(d, id);
		}
	}
	
	return position;


}

