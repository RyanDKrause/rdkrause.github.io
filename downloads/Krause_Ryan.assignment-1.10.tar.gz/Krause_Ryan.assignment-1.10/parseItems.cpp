#include <fstream>
using std::ifstream;

#include <cstring>
#include <cstdlib> //Getenv
#include <cstdlib> //stuff
#include <iostream> //print stuff
#include <vector> //for vectors. Duh.
using namespace std;

#include "items.h" //ITEM class
#include "dice.h" //Dice class

//Keys for file parsing, found using hash function
#define NAME 11177928
#define COLOR 356328934
#define DESC 10823110
#define TYPE 11419785
#define SPEED 375331640
#define DAMAGE 327833
#define WEIGHT 12529586703
#define HIT 332460
#define VALUE 347434
#define DODGE 357505866
#define ATTR 10731682
#define DEFENSE 327958
#define END 329342

void Item::set(const string &name,
				const string &description,
				const string &color,
				const string &type,
				const dice &speed,
				const dice &damage,
				const dice &hit,
				const dice &dodge,
				const dice &defense,
				const dice &weight,
				const dice &attr,
				const dice &value)
{
  this->name = name;
  this->description = description;
  this->color = color;
  this->type = type;
  this->speed = speed;
  this->damage = damage;
  this->hit = hit;
  this->dodge = dodge;
  this->defense = defense;
  this->weight = weight;
  this->attr = attr;
  this->value = value;
}


//djb2 Dan Bernstein hashing function V2.0
unsigned long hash(const char *str) {
    unsigned long hash = 7; //5381 is the original number for some reason
    int c;

    while ((c = *str++)) {
		
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
		//hash = hash * 31 + c;
		//cout << "C: " << c << endl;
    }
	
	return hash;
}

int parse_items(dungeon *d) {

	char *path; // Absolute path to the file
	char *home; // The name of our home directory
	const char *file; // The name of the file
	ifstream f; //reading the file
	
	const int MAX_CHARS = 80;
	const int MAX_TOKENS = 80;
	const char* const DELIMITER = " ";
	
	vector<Item> *v;
		

	home = getenv("HOME");
	file = ".rlg229/object_desc.txt";
	path = (char*) malloc(strlen(home) + strlen(file) + 2 ); //2 is for the NULL and internal /
	
	if (!path) {
		fprintf(stderr, "malloc failed!\n");
		return 1;
	}
	
	sprintf(path, "%s/%s", home, file);
	
	f.open(path); //open the file, it's already been defined as an INstream, reading only. 
	
	free(path);
	
	if (!f.good()) {
		fprintf(stderr, "File not found!!\n");
		return 404; //File not found
	}
	
	int right_file = 0;
	
	v = new vector<Item>();
	d->item_templates = v;

	while (!f.eof()) {
		//read the next line
		char next_line[MAX_CHARS];
		
		if (!right_file) {
			f.getline(next_line, MAX_CHARS);
			if (strcmp(next_line, "RLG229 OBJECT DESCRIPTION 1") == 0) {
				right_file = 1;
			}
			else {
				cout << "Wrong file" << endl;
				break; //WRONG FILE
			}
		}
		
		//save the tokens (words and such)
		char* token[MAX_TOKENS] = {}; //initialize them all to 0.
		
		f.getline(next_line, MAX_CHARS);
		if (strcmp(next_line, "BEGIN OBJECT") == 0) { // start of item stuff
			
			Item temp;
			
			//cout << "STARTING NEW OBJECT" << endl;
			
			int name_flag = 0;
			int desc_flag = 0;
			int type_flag = 0;
			int color_flag = 0;
			int speed_flag = 0;
			int damage_flag = 0;
			int hit_flag = 0;
			int dodge_flag = 0;
			int def_flag = 0;
			int weight_flag = 0;
			int attr_flag = 0;
			int end_flag = 0;
			int value_flag = 0;
			int error_flag = 0;
						
			int temp_b;
			int temp_num;
			int temp_s;
			
			string name, desc, color, type;
			dice speed, damage, hit, dodge, defense, weight, attr, value;
						
			while (!end_flag) {
		
				if (error_flag) break; //error with a file
				
				f.getline(next_line, MAX_CHARS);
				token[0] = strtok(next_line, DELIMITER);
					
				while (strlen(next_line) == 0) {
					f.getline(next_line, MAX_CHARS);
					token[0] = strtok(next_line, DELIMITER);
				}
								
				switch (hash(token[0])) { //can't use strings with a switch statement! Need an int value.
				
					case NAME:
						if (name_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, "\n");
						name = token[1];
						name_flag = 1;
						break;
					
					case COLOR:
						if (color_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, DELIMITER);
						color = token[1];
						color_flag = 1;
						break;
						
					case TYPE:
						if (type_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, "\n");
						type = token[1];
						type_flag = 1;
						break;
						
					case SPEED:
						if (speed_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						speed.set(temp_b, temp_num, temp_s);
						speed_flag = 1;
						break;
						
					case WEIGHT:
						if (weight_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						weight.set(temp_b, temp_num, temp_s);
						weight_flag = 1;
						break;
					
					case HIT:
						if (hit_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						hit.set(temp_b, temp_num, temp_s);
						hit_flag = 1;
						break;
						
					case VALUE:
						if (value_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						value.set(temp_b, temp_num, temp_s);
						value_flag = 1;
						break;
					
					case DODGE:
						if (dodge_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						dodge.set(temp_b, temp_num, temp_s);
						dodge_flag = 1;
						break;
						
					case ATTR:
						if (attr_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						attr.set(temp_b, temp_num, temp_s);
						attr_flag = 1;
						break;
						
					case DEFENSE:
						if (def_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						defense.set(temp_b, temp_num, temp_s);
						def_flag = 1;
						break;
					case DAMAGE:
						if (damage_flag) {
							error_flag = 1;
						}
						
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);
		
						damage.set(temp_b, temp_num, temp_s);
						damage_flag = 1;
						break;
					
					case DESC:
						if (desc_flag) {
							error_flag = 1;
						}
						
						while (strcmp(next_line, ".") != 0) {
						f.getline(next_line, MAX_CHARS);
						
						if (strcmp(next_line, ".") == 0) {
							break;
						}
						
						desc +=  next_line;
						desc += "\n";
						
						}
						
						desc_flag = 1;
						break;
					
					case END:
						if (name_flag && desc_flag && type_flag && color_flag && speed_flag && damage_flag && hit_flag && dodge_flag && def_flag && weight_flag && attr_flag && value_flag) { //The U.N. is jealous of all my flags.
							end_flag = 1;
						}
						else {
							error_flag = 1;
						}
						break;
											
					default:
						error_flag = 1;
						token[1] = strtok(0, DELIMITER);
						cout << "Error on: " << token[0] << endl;
						cout << "Default hash: " << hash(token[0]) << endl;
						break;
				}
			}
						
			if (!error_flag) {
				//WE MADE IT BOYZ
			
				//add the NPC to a place? 
				
				temp.set(name, desc, color, type, speed, damage, hit, dodge, defense, weight, attr, value);
				v->push_back(temp);
								
				//monster_count++;
				//cout << "END OF MONSTER" << endl;
			}
			else {
				cout << "This monster had an issue somewhere." << endl;
				cout << "FLAGS: " << name_flag << desc_flag << type_flag << color_flag << speed_flag << damage_flag  << hit_flag << dodge_flag << def_flag << weight_flag << attr_flag << value_flag << endl;
			
			}

			
		}
		else {
			//There was an issue, keep looking for a monster start
			//leave++; //if this reaches 50, we just stop looking?
		}
		//cout << "Help!" << leave << endl;
	}
	
	return 0;
}

int print_items(dungeon *d) {

	unsigned int i; 

	vector<Item> *v;
	
	v = (vector<Item> *) d->item_templates;
	
	
	for (i = 0; i < v->size(); i++) {
		
		Item my_item = v->at(i);
		my_item.print();	
		
	}
	
	return 0;
	
}

int destroy_items(dungeon *d) {
	
	delete (vector<Item> *) d->item_templates;
	d->item_templates = NULL;

	return 0; 
}

item_types_t convert_item_type(char* str) {
	

	if (strcmp(str, "WEAPON") == 0) {
		return WEAPON;
	}
	else if (strcmp(str, "OFFHAND") == 0) {
		return OFFHAND;
	}
	else if (strcmp(str, "RANGED") == 0) {
		return RANGED;
	}
	else if (strcmp(str, "ARMOR") == 0) {
		return ARMOR;
	}
	else if (strcmp(str, "HELMET") == 0) {
		return HELMET;
	}
	else if (strcmp(str, "CLOAK") == 0) {
		return CLOAK;
	}
	else if (strcmp(str, "GLOVES") == 0) {
		return GLOVES;
	}
	else if (strcmp(str, "BOOTS") == 0) {
		return BOOTS;
	}
	else if (strcmp(str, "RING") == 0) {
		return RING;
	}
	else if (strcmp(str, "AMULET") == 0) {
		return AMULET;
	}
	else if (strcmp(str, "LIGHT") == 0) {
		return LIGHT;
	}
	else if (strcmp(str, "SCROLL") == 0) {
		return SCROLL;
	}
	else if (strcmp(str, "BOOK") == 0) {
		return BOOK;
	}
	else if (strcmp(str, "FLASK") == 0) {
		return FLASK;
	}
	else if (strcmp(str, "GOLD") == 0) {
		return GOLD;
	}
	else if (strcmp(str, "AMMUNITION") == 0) {
		return AMMUNITION;
	}
	else if (strcmp(str, "FOOD") == 0) {
		return FOOD;
	}
	else if (strcmp(str, "WAND") == 0) {
		return WAND;
	}
	else if (strcmp(str, "CONTAINER") == 0) {
		return CONTAINER;
	}
	else if (strcmp(str, "STACK") == 0) {
		return STACK;
	}
	
	return INVALID;
}

int generate_items(dungeon *d, int count) {

	vector<Item> *v;
	
	v = (vector<Item> *) d->item_templates;
	
	int i;
	for (i = 0; i < count; i++) {
		int rand_num = rand() % v->size();
		int randnum = rand() % d->room_count;
		Item my_item = v->at(rand_num);
		item new_item = my_item.create_item();
		new_item.current_pos.x = d->rooms_array[randnum].start_x + rand() % d->rooms_array[randnum].room_width;
		new_item.current_pos.y = d->rooms_array[randnum].start_y + rand() % d->rooms_array[randnum].room_height;
		new_item.visible = 1;
		d->items_array[i] = new_item;
		d->items_count++;
		
		//free(new_item.name);
		//free(new_item.description);
		//free(new_item.color);
		//free(new_item.type);
	
	}
	return 0;	


}