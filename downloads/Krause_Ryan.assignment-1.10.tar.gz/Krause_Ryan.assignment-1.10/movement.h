#ifndef MOVEMENT_H
#define MOVEMENT_H

square player_move(dungeon *d, int id);
square monster_move(dungeon *d, int id);
void player_move_true(dungeon *d, character *ch, int direction);


#endif