#include <fstream>
using std::ifstream;

#include <cstring>
#include <cstdlib> //stuff
#include <iostream> //print stuff
#include <vector> //for vectors. Duh.
using namespace std;

#include "npc.h" //NPC class
#include "dice.h" //Dice class

//Keys for file parsing, found using hash function
#define NAME 11177928
#define SYMBOL 11383746
#define COLOR 356328934
#define DESC 10823110
#define SPEED 375331640
#define DAMAGE 327833
#define HP 10079
#define ABILITY 10711711
#define END 329342


void NPC::set(const string &name,
                              const string &description,
                              const char symbol,
                              const string &color,
                              const dice &speed,
                              const string &abilities,
                              const dice &hitpoints,
                              const dice &damage)
{
  this->name = name;
  this->description = description;
  this->symbol = symbol;
  this->color = color;
  this->speed = speed;
  this->abilities = abilities;
  this->hitpoints = hitpoints;
  this->damage = damage;
}


//djb2 Dan Bernstein hashing function V2.0
unsigned long hash(const char *str) {
    unsigned long hash = 7; //5381 is the original number for some reason
    int c;

    while ((c = *str++)) {
		
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
		//hash = hash * 31 + c;
		//cout << "C: " << c << endl;
    }
	
	return hash;
}

int parse_monsters(dungeon *d) {

	char *path; // Absolute path to the file
	char *home; // The name of our home directory
	const char *file; // The name of the file
	ifstream f; //reading the file
	
	const int MAX_CHARS = 80;
	const int MAX_TOKENS = 80;
	const char* const DELIMITER = " ";
	
	vector<NPC> *v;
		

	home = getenv("HOME");
	file = ".rlg229/monster_desc.txt";
	path = (char*) malloc(strlen(home) + strlen(file) + 2 ); //2 is for the NULL and internal /
	
	if (!path) {
		fprintf(stderr, "malloc failed!\n");
		return 1;
	}
	
	sprintf(path, "%s/%s", home, file);
	
	f.open(path); //open the file, it's already been defined as an INstream, reading only. 
	
	free(path);
	
	if (!f.good()) {
		fprintf(stderr, "File not found!!\n");
		return 404; //File not found
	}
	
	int right_file = 0;
	
	v = new vector<NPC>();
	d->monster_templates = v;

	while (!f.eof()) {
		//read the next line
		char next_line[MAX_CHARS];
		
		if (!right_file) {
			f.getline(next_line, MAX_CHARS);
			if (strcmp(next_line, "RLG229 MONSTER DESCRIPTION 1") == 0) {
				right_file = 1;
			}
			else {
				cout << "Wrong file" << endl;
				break; //WRONG FILE
			}
		}
		
		//save the tokens (words and such)
		char* token[MAX_TOKENS] = {}; //initialize them all to 0.
		
		f.getline(next_line, MAX_CHARS);
		if (strcmp(next_line, "BEGIN MONSTER") == 0) { // start of monster stuff
			
			NPC temp;
			
			//cout << "STARTING NEW MONSTER" << endl;
			
			int name_flag = 0;
			int symbol_flag = 0;
			int desc_flag = 0;
			int color_flag = 0;
			int speed_flag = 0;
			int damage_flag = 0;
			int hp_flag = 0;
			int ability_flag = 0;
			int end_flag = 0;
			int error_flag = 0;
			
			int temp_b;
			int temp_num;
			int temp_s;
			
			string name, desc, color, ability;
			dice speed, damage, hitpoints;
			char symbol;
						
			while (!end_flag) {
		
				if (error_flag) break; //error with a file
				
				f.getline(next_line, MAX_CHARS);
				token[0] = strtok(next_line, DELIMITER);
					
				while (strlen(next_line) == 0) {
					f.getline(next_line, MAX_CHARS);
					token[0] = strtok(next_line, DELIMITER);
				}
								
				switch (hash(token[0])) { //can't use strings with a switch statement! Need an int value.
				
					case NAME:
						if (name_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, "\n");
						name = token[1];
						name_flag = 1;
						break;
					
					case SYMBOL:
						if (symbol_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, DELIMITER);
						symbol = *token[1];
						symbol_flag = 1;
						break;
					
					case COLOR:
						if (color_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, DELIMITER);
						color = token[1];
						color_flag = 1;
						break;
						
					case SPEED:
						if (speed_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);

						speed.set(temp_b, temp_num, temp_s);
						speed_flag = 1;
						break;
					
					case DAMAGE:
						if (damage_flag) {
							error_flag = 1;
						}
						
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);
		
						damage.set(temp_b, temp_num, temp_s);
						damage_flag = 1;
						break;
					
					case HP:
						if (hp_flag) {
							error_flag = 1;
						}
						
						token[1] = strtok(0, " +d");
						token[2] = strtok(0, " +d");
						token[3] = strtok(0, " +d");
						
						temp_b = atoi(token[1]);
						temp_num = atoi(token[2]);
						temp_s = atoi(token[3]);
	
						hitpoints.set(temp_b, temp_num, temp_s);
						hp_flag = 1;
						break;
				
					case ABILITY:
						if (ability_flag) {
							error_flag = 1;
						}
						token[1] = strtok(0, "\n");
						ability += token[1];
						ability_flag = 1;
						break;
					
					case DESC:
						if (desc_flag) {
							error_flag = 1;
						}
						
						while (strcmp(next_line, ".") != 0) {
							f.getline(next_line, MAX_CHARS);
							
							if (strcmp(next_line, ".") == 0) {
								break;
							}
							
							desc +=  next_line;
							desc += "\n";
						}
						
						desc_flag = 1;
						break;
					
					case END:
						if (name_flag && symbol_flag && desc_flag && color_flag && speed_flag && damage_flag && hp_flag && ability_flag) { //The U.N. is jealous of all my flags.
							end_flag = 1;
						}
						else {
							error_flag = 1;
						}
						break;
											
					default:
						error_flag = 1;
						token[1] = strtok(0, DELIMITER);
						cout << "Error on: " << token[0] << endl;
						cout << "Default hash: " << hash(token[0]) << endl;
						break;
				}
			}
						
			if (!error_flag) {
				//WE MADE IT BOYZ
			
				//add the NPC to a place? 
				
				temp.set(name, desc, symbol, color, speed, ability, hitpoints, damage);
				v->push_back(temp);
								
				//monster_count++;
				//cout << "END OF MONSTER" << endl;
			}
			else {
				cout << "This monster had an issue somewhere." << endl;
			
			}

			
		}
		else {
			//There was an issue, keep looking for a monster start
		}
		//cout << "Help!" << leave << endl;
	}
	
	return 0;
}

int print_monsters(dungeon *d) {

	unsigned int i; 

	vector<NPC> *v;
	
	v = (vector<NPC> *) d->monster_templates;
	
	
	for (i = 0; i < v->size(); i++) {
		
		NPC my_monsters = v->at(i);
		
		my_monsters.print();
		
	}
	
	return 0;
	
}

int destroy_monsters(dungeon *d) {
	
	delete (vector<NPC> *) d->monster_templates;
	d->monster_templates = NULL;

	return 0; 
}

int generate_monster(dungeon *d) {
	
	vector<NPC> *v;
	
	v = (vector<NPC> *) d->monster_templates;
	
	int rand_num = rand() % v->size();
	
	NPC my_monster = v->at(rand_num);
	
	character new_monster = my_monster.create_monster();
	
	
	d->monsters_array[d->monsters_count+1] = new_monster;
	
	d->monsters_count++;
	
	//free(new_monster.name);
	//free(new_monster.desc);
	//free(new_monster.color);

	return 0;


}

