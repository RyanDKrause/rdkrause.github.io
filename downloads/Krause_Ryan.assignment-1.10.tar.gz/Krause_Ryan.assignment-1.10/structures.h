#ifndef STRUCTURES_H
#define STRUCTURES_H

# ifdef __cplusplus
extern "C" {
# endif

//dungeon constants
#define WIDTH 160
#define HEIGHT 96
#define MAX_MONSTERS 1000
#define MAX_ITEMS 1000

//rock constants
#define START_ROCK 999 //everything starts like this. Is never printed (should be anyway)
#define IMPOSSIBLE_ROCK 255 //impossible to go through
#define EMPTY_SPACE 0
#define BUFFER_SPACE 998 //buffer zone to make sure rooms are spread out
#define MONSTER_SPACE 997 //the path our monster will take when we have a monster.
#define PLAYER_SPACE 996 //the current position of the player.
#define STAIR_UP 995 //stairs that go up
#define STAIR_DOWN 994 //stairs that go down


typedef struct room room; //need to declare this before struct because room is used in room.

struct room {
	int id;
	int room_width;
	int room_height;
	int start_x;
	int start_y;
	int connected;
	int distance;
	int prev_dist;
	//struct room *connected_room;
	int connected_room[21];
};


typedef struct square {
	int x;
	int y;
} square;

typedef struct dice_c {
	int base;
	int num_dices;
	int sides;
} dice_c;

typedef struct item {
	char name[100];
	char* description;
	char color[20];
	char type[20];
	int speed;
	int hit;
	int dodge;
	int defense;
	int weight;
	int attr;
	int value;
	dice_c damage;
	square current_pos; 
	int visible;
} item;

typedef struct inventory_t {
	
	item weapon;
	item offhand;
	item ranged;
	item armor;
	item helmet;
	item cloak;
	item gloves;
	item boots;
	item amulet;
	item light;
	item ring1;
	item ring2;
	item carrying[10];
	int items_carrying;

} inventory_t;

typedef struct character {
	int speed;
	int next_turn;
	int player; //1 if is player
	int smart; //0 if no, 1 if yes
	int tele; //0 if no, 1 if yes
	square current_pos; 
	int alive; //1 if alive
	char name[100];
	char* desc;
	char symbol;
	char color[20];
	int hitpoints;
	dice_c damage;
	inventory_t inventory;
	
} character;

typedef void *monster_template_t;
typedef void *item_template_t;

typedef struct dungeon {
	int room_count;
	int monsters_count;
	int items_count;
	int width;
	int height;
	int floor_plan[WIDTH][HEIGHT]; //holds rock type of every space in the dungeon.
	int dist_plan[WIDTH][HEIGHT]; //holds the distance it takes to go from x to this space, used in BFS.
	int empty_space[WIDTH][HEIGHT]; //holds 0 if rock, 1 if room, 2 if corridor, 3 stairs up, 4 stairs down
	room rooms_array[21]; 
	//int player_pos[2];
	character monsters_array[MAX_MONSTERS];
	item items_array[MAX_ITEMS];
	int game_on; //0 if game over, 1 if dungeon is created and running, 2 otherwise
	monster_template_t monster_templates;
	item_template_t item_templates;
} dungeon;

# ifdef __cplusplus
}
# endif

#endif
