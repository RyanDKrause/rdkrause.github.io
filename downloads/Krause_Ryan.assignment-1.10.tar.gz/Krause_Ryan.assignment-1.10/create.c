#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "structures.h"
#include "queue.h"

#define DIFFICULTY 10 //how often we have to curve our corridors, 0 = straight. 


int roll_damage(dice_c d) {
	int total = 0;
	int i;
	
	total += d.base;
	
	if (d.sides) {
		for (i = 0; i < d.num_dices; i++) {
			total += rand() % d.sides + 1;
		}
	}
	
	return total;
	

}

int low_roll(dice_c d) {
	return d.base;
}

int high_roll(dice_c d) {
	return d.base + d.num_dices*d.sides;
}

void initialize_dungeon(dungeon *d) {

	d->room_count = 0;
	d->width = WIDTH;
	d->height = HEIGHT;
	d->monsters_count = 0;
	d->items_count = 0;
	d->game_on = 1;
	
	int i, j;
	
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			d->floor_plan[i][j] = START_ROCK;
			d->dist_plan[i][j] = 0; 
			d->empty_space[i][j] = 0;
		}
	}
	
}

void add_room(dungeon *d) {

	room rm;
	
	rm.room_width = 12 + rand() % 10; //change this to whatever max width is
	rm.room_height = 5 + rand() % 10; //change this to whatever max height is
	rm.start_x = 1 + (rand() % (d->width-1 - (rm.room_width)));
	rm.start_y = 1 + (rand() % (d->height-1 - (rm.room_height)));

	rm.connected = 0;
	
	rm.id = d->room_count+1;
	
	int i,j;
	
	
	for (i = 0; i < rm.room_height; i++) {
		for (j=0; j < rm.room_width; j++) {
			if (d->floor_plan[j+rm.start_x][i+rm.start_y] != START_ROCK) {
				//printf("No\n");
				return;
			}
		}
	}
	
	for (i = 0; i < rm.room_height; i++) {
		for (j=0; j < rm.room_width; j++) {
			d->floor_plan[j+rm.start_x][i+rm.start_y] = EMPTY_SPACE;
			d->empty_space[j+rm.start_x][i+rm.start_y] = 1;
		}
	}
	
	//top buffer
	for (i = -3; i < 0; i++) {
		for (j=-3; j < rm.room_width+3; j++) {
			if (j+rm.start_x > 0 && i+rm.start_y > 0 && j+rm.start_x < WIDTH) {
				d->floor_plan[j+rm.start_x][i+rm.start_y] = BUFFER_SPACE;
			}
		}
	}
	
	//bottom buffer
	for (i = rm.room_height; i < rm.room_height+3; i++) {
		for (j=-3; j < rm.room_width+3; j++) {
			if (j+rm.start_x > 0 && i+rm.start_y < HEIGHT && j+rm.start_x < WIDTH) {
				d->floor_plan[j+rm.start_x][i+rm.start_y] = BUFFER_SPACE;
			}
		}
	}
	
	//left buffer
	for (i = 0; i < rm.room_height+3; i++) {
		for (j=-3; j < 0; j++) {
			if (j+rm.start_x > 0 && i+rm.start_y > 0 && i+rm.start_y < HEIGHT) {
				d->floor_plan[j+rm.start_x][i+rm.start_y] = BUFFER_SPACE;
			}
		}
	}
	
	//right buffer
	for (i = 0; i < rm.room_height+3; i++) {
		for (j=rm.room_width; j < rm.room_width+3; j++) {
			if (j+rm.start_x > 0 && i+rm.start_y > 0 && i+rm.start_y < HEIGHT) {
				d->floor_plan[j+rm.start_x][i+rm.start_y] = BUFFER_SPACE;
			}
		}
	}
		
	d->rooms_array[d->room_count] = rm; 	
	d->room_count++;
	
	
	
}

void print_dungeon(dungeon *d) {

	int i,j,k;
	int id;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
		
			if (d->floor_plan[i][j] == START_ROCK) {
				printf("M"); //shouldn't be shown
			}
			else if (d->floor_plan[i][j] == EMPTY_SPACE) {
				printf(".");
			}
			else if (d->floor_plan[i][j] == PLAYER_SPACE) {
				printf("@");
			}
			else if (d->floor_plan[i][j] == BUFFER_SPACE) {
				printf("b"); //for testing purposes, will never show up
			}
			else if (d->floor_plan[i][j] == IMPOSSIBLE_ROCK) {
				//printf("X"); //again, testing.
				printf("#");
			}
			else if (d->floor_plan[i][j] == MONSTER_SPACE) {				
				for (k = 1; k < MAX_MONSTERS; k++) {
					if (i == d->monsters_array[k].current_pos.x && j == d->monsters_array[k].current_pos.y) {
						id = k;
					}		
				}
				
				if (d->monsters_array[id].tele) {
					if (d->monsters_array[id].smart) {
						//space = 'T';
						printf("T");
					}
					else {
						//space = 't';
						printf("t");
					}
				}
				else {
					if (d->monsters_array[id].smart) {
						//space = 'S';
						printf("S");
					}
					else {
						//space = 's';
						printf("s");
					}
				}				
			}
			else if (d->floor_plan[i][j] == STAIR_UP) {
				printf("<");
			}
			else if (d->floor_plan[i][j] == STAIR_DOWN) {
				printf(">");
			}
			else {
				printf("#"); //reasons.
			}
		}
		printf("\n");
	}

}

void update_rocks(dungeon *d) {
	int i,j;	
	
	//gets rid of the buffer spaces around rooms. 
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->floor_plan[i][j] == BUFFER_SPACE) {
				d->floor_plan[i][j] = START_ROCK;
			}
		}
	}
	
	//a rock has a DIFFICULTY% chance of being impossible to go through
	//needed for tunnel planning currently.
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->floor_plan[i][j] == START_ROCK) {
				int num = rand() % 100;
				if (num < DIFFICULTY) {
					d->floor_plan[i][j] = IMPOSSIBLE_ROCK;
				}
				
			}
		}
	}
	
	
	//Make the borders impossible to go through
	for (i = 0; i < WIDTH; i++) {
		d->floor_plan[i][0] = IMPOSSIBLE_ROCK;
		d->floor_plan[i][HEIGHT-1] = IMPOSSIBLE_ROCK;
	}
	for (j = 0; j < HEIGHT; j++) {
		d->floor_plan[0][j] = IMPOSSIBLE_ROCK;
		d->floor_plan[WIDTH-1][j] = IMPOSSIBLE_ROCK;
	} 
}

void update_hardness(dungeon *d) {

//gets rid of the impossible rock for now (we used it for BFS). 
	int i,j;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->floor_plan[i][j] == IMPOSSIBLE_ROCK) {
				d->floor_plan[i][j] = START_ROCK;
			}
		}
	}
	
	//Now, anything that isn't a room or corridor (start_rock) needs to get a new hardness
	//between 1 and 255 inclusive. 
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->floor_plan[i][j] == START_ROCK) {
				d->floor_plan[i][j] = 1 + rand() % 255;
			}
		}
	}
}

void BFS(dungeon *d, int room_number) {

	queue q;
	
	queue_init(&q);
	
	room start = d->rooms_array[room_number];
		
	int current_x = start.start_x + start.room_width/2;
	int current_y = start.start_y + start.room_height/2;
		
	int distance = 10000; //big number
	
	int goal_x;
	int goal_y;
	int dist_traveled = 0;
	
	room goal_room;
	int goal_room_num;
	
	int i, j;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			d->dist_plan[i][j] = 0;
		}
	}
	
	if (start.connected >= 3) {
		return; //PEACE OUT YO
	}
	
	for (i = 0; i < d->room_count; i++) {
		room temp = d->rooms_array[i];
		
		for (j = 0; j < start.connected; j++) {
			if (start.connected_room[j] == temp.id) {
				//printf("%d is connected to %d", start.id, temp.id);
				temp.connected = 10;
				
			}			
		}
		//printf("We broke.\n");
		
		
		if (temp.connected <= 3) {
				//printf("%d, %d\n", i, temp.connected);
			
			int temp_mid_x = temp.start_x + (temp.room_width/2);
			int temp_mid_y = temp.start_y + (temp.room_height/2);
			
			int temp_distance = (temp_mid_x - current_x)*(temp_mid_x - current_x) + (temp_mid_y - current_y)*(temp_mid_y - current_y);
			temp_distance = sqrt(temp_distance);
			
			if (temp_distance < distance && temp_distance > 1) { //make sure it's not itself
				distance = temp_distance;
				goal_x = temp_mid_x;
				goal_y = temp_mid_y;
				goal_room = temp;
				goal_room_num = i;
			}
		
		}
	}
	
	
	start.connected_room[start.connected] = goal_room.id;
	goal_room.connected_room[goal_room.connected] = start.id;
	
	start.connected += 1;
	goal_room.connected += 1;
	
	//printf ("%d: %d\n", room_number, start.connected);
	//printf ("%d: %d\n\n", goal_room_num, goal_room.connected);
	d->rooms_array[room_number] = start;
	d->rooms_array[goal_room_num] = goal_room;
	
	
	
	
	d->dist_plan[current_x][current_y] = 999;
		
	queue_add(&q, current_x+1, current_y, 1);
	queue_add(&q, current_x-1, current_y, 1);
	queue_add(&q, current_x, current_y+1, 1);
	queue_add(&q, current_x, current_y-1, 1);
	
	
	while(q.size != 0) {
		
		if (current_x == goal_x && current_y == goal_y) {
			break; //because reasons.
		}
		if (dist_traveled > 500) {
			return; //issue... it can't find anything?
		}
		
		if ((current_x < WIDTH-1 || current_x > 1) && (current_y < HEIGHT - 1 || current_y > 1)) {
			queue_remove(&q, &current_x, &current_y, &dist_traveled);
			
							
			if (d->dist_plan[current_x][current_y] == 0 && d->floor_plan[current_x][current_y] != IMPOSSIBLE_ROCK) {
			
				if (d->dist_plan[current_x][current_y] != 999) {
					
					d->dist_plan[current_x][current_y] = dist_traveled;
					
					if (current_x < WIDTH-2 && current_x > 2 && current_y < HEIGHT - 2 && current_y > 2) {
						queue_add(&q, current_x+1, current_y, dist_traveled+1);
						queue_add(&q, current_x-1, current_y, dist_traveled+1);
						queue_add(&q, current_x, current_y+1, dist_traveled+1);
						queue_add(&q, current_x, current_y-1, dist_traveled+1);
					}
				}
			}
		}		
	}
	//we found a path! wait... maybe not...
	if (q.size == 0) {
		printf("Uh oh... No path found...");
		//nailed it.
		//start->connected-= 1;
		//goal_room->connected -= 1; //old stuff, don't think needed.
		return; //well crap.
	}
	
	//Ok! NOW we found a path for sure!
	
	//make it so all other spaces are too high to go to!
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->dist_plan[i][j] == 0) {
				d->dist_plan[i][j] = 999;
			}
		}
	}
	
	while(dist_traveled > 2) {
		
		//find which direction leads us back to the start and go that way
		
		//update the path with an empty space
		d->floor_plan[current_x][current_y] = EMPTY_SPACE;
		if (d->empty_space[current_x][current_y] != 1) {
			d->empty_space[current_x][current_y] = 2; //make this a corridor space
		}
		if (d->dist_plan[current_x+1][current_y] < dist_traveled) {
			dist_traveled -= 1;
			current_x += 1;
		}
		else if (d->dist_plan[current_x-1][current_y] < dist_traveled) {
			dist_traveled -= 1;
			current_x -= 1;
		}
		else if (d->dist_plan[current_x][current_y+1] < dist_traveled) {
			dist_traveled -= 1;
			current_y += 1;
		}
		else if (d->dist_plan[current_x][current_y-1] < dist_traveled) {
			dist_traveled -= 1;
			current_y -= 1;
		}
		else {
			printf("help");
		}	
	}
	
	
	while (!queue_remove(&q, &current_x, &current_y, &dist_traveled)); //free queue
	
	//made a path, everything is connected!
	
}

void add_stairs(dungeon *d) {
	
	int stair_count = 0;
	
	while (stair_count != 2) {
	
		int randnum  = rand() % d->room_count;
		int randx = d->rooms_array[randnum].start_x + rand() % d->rooms_array[randnum].room_width;
		int randy = d->rooms_array[randnum].start_y + rand() % d->rooms_array[randnum].room_height;
		
		if (d->floor_plan[randx][randy] == EMPTY_SPACE) {
			if (stair_count == 0) {
				d->floor_plan[randx][randy] = STAIR_UP;
				d->empty_space[randx][randy] = 3;
				stair_count++;
			}
			else {
				d->floor_plan[randx][randy] = STAIR_DOWN;
				d->empty_space[randx][randy] = 4;
				stair_count++;
			}
		}
	}
}

void create_dungeon(dungeon *d) {
	
	int i;
	while (d->room_count != 20) { //20 is random.
		add_room(d); 
	}
	
	d->game_on = 4;
	
	update_rocks(d); //Gets rid of buffer zones and adds impossible rock
	d->game_on = 5;
	for (i = 0; i < 20; i++) {
		BFS(d, i); //assorted calls
		BFS(d, i);
		BFS(d, i);
	
	}
	
	d->game_on = 6;
	update_hardness(d);
	
	d->game_on = 7;
	
	add_stairs(d);
	
	d->game_on = 8;

}


void free_characters_and_inventory(dungeon *d){


	int i;
	
	
	for (i = 0; i < d->monsters_array[0].inventory.items_carrying; i++) {
		free(d->monsters_array[0].inventory.carrying[i].name);
		free(d->monsters_array[0].inventory.carrying[i].description);
		free(d->monsters_array[0].inventory.carrying[i].color);
		free(d->monsters_array[0].inventory.carrying[i].type);
	}
	
	
	if (d->monsters_array[0].inventory.weapon.name != NULL) {
		free(d->monsters_array[0].inventory.weapon.name);
		free(d->monsters_array[0].inventory.weapon.description);
		free(d->monsters_array[0].inventory.weapon.color);
		free(d->monsters_array[0].inventory.weapon.type);
	}
	
	if (d->monsters_array[0].inventory.offhand.name != NULL) {
		free(d->monsters_array[0].inventory.offhand.name);
		free(d->monsters_array[0].inventory.offhand.description);
		free(d->monsters_array[0].inventory.offhand.color);
		free(d->monsters_array[0].inventory.offhand.type);
	}

	
	for (i = 0; i < d->items_count; i++) {
		free(d->items_array[i].name);
		free(d->items_array[i].description);
		free(d->items_array[i].color);
		free(d->items_array[i].type);
	}
	
	for (i = 1; i < d->monsters_count; i++) {
		free(d->monsters_array[i].name);
		free(d->monsters_array[i].desc);
		free(d->monsters_array[i].color);
		
	}
	
}

