#ifndef PQUEUE_H
#define PQUEUE_H

typedef struct pQueue_node {
  //struct pQueue_node *next;
  int distance;
  int x;
  int y;
  int priority;
} pQueue_node;

typedef struct pQueue {
  //queue_node *head, *tail;
  pQueue_node heap[100];
  int array_size; //space for elements
  int size; //used elements
} pQueue;

void initialize_pQueue(pQueue *p);
void shift_up(pQueue *p, int i);
void add_pQueue(pQueue *p, int x, int y, int dist);
void shift_down(pQueue *p, int i);
void remove_pQueue(pQueue *p, int *x, int *y, int *dist);
void free_pQueue(pQueue *p);
void Dijkstra(dungeon *d, int start_x, int start_y, int goal_x, int goal_y);
square bad_Dijkstra(dungeon *d, int start_x, int start_y, int goal_x, int goal_y);

#endif
