#ifndef NPC_H
#define NPC_H

#include <math.h>
#include "structures.h"
#include "dice.h"

# ifdef __cplusplus

extern "C" {
# endif

unsigned long hash(const char *str);
int parse_monsters(dungeon *d);
int print_monsters(dungeon *d);
int destroy_monsters(dungeon *d);
int generate_monster(dungeon *d);
# ifdef __cplusplus
}

class NPC {
private:

	string name, description, color, abilities;
	char symbol;
	dice speed, hitpoints, damage;
	
	
public:

	NPC() : name(), description(), color(), abilities(), symbol(0), speed(),
			hitpoints(), damage() 
	{
	}
	
	void set(const string &name, const string &description, const char symbol,
			const string &color, const dice &speed, const string &abilities,
			const dice &hitpoints, const dice &damage);

	inline void print() {
		cout << name << endl;		
		cout << description;// << endl; //there's an extra new line in my description anyway
		cout << symbol << endl;	
		cout << color << endl;
		cout << speed.get_base() << "+" << speed.get_number() << "d" << speed.get_sides() << endl;	
		cout << abilities << endl;	
		cout << hitpoints.get_base() << "+" << hitpoints.get_number() << "d" << hitpoints.get_sides() << endl;
		cout << damage.get_base() << "+" << damage.get_number() << "d" << damage.get_sides() << endl;	
		cout << endl;
		
		
	}
	
	inline character create_monster() {
		character temp;
		
		//temp.name = strdup(this->name);
		//free(temp.name);
		//temp.name = (char *) malloc(sizeof(char) * (name.length() + 1));
		strcpy(temp.name, this->name.c_str());
		//temp.desc = strdup(this->description);
		
		//free(temp.desc);
		//temp.desc = (char *) malloc(sizeof(char) * (description.length() + 1));
		//strcpy(temp.desc, this->description.c_str());
		//temp.color = strdup(this->color);
		//free(temp.color);
		//temp.color = (char *) malloc(sizeof(char) * (color.length() + 1));
		strcpy(temp.color, this->color.c_str());
		
		temp.speed = roll(this->speed);
		temp.hitpoints = roll(this->hitpoints);
		//temp.damage = this->damage;
		temp.damage = convert_to_c(this->damage); //get rid of C++ class to C struct
		temp.next_turn = floor(100/temp.speed);
		temp.player = 0;
		temp.alive = 1;
		temp.symbol = symbol;
		
		if (this->abilities.find("TELE") != std::string::npos) {
			temp.tele = 1;
		}
		if (this->abilities.find("SMART") != std::string::npos) {
			temp.smart = 1;
		}
	
		//square current_pos; //TODO OUTSIDE OF FUNCTION
	
		return temp;
	}
};

# endif



#endif
