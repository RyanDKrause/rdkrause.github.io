#ifndef QUEUE_H
#define QUEUE_H

typedef struct queue_node {
  struct queue_node *next;
  int distance;
  int x;
  int y;
  int found_rock;
} queue_node;

typedef struct queue {
  queue_node *head, *tail;
  int size;
} queue;

void queue_add(queue *q, int x, int y, int dist);
int queue_remove(queue *q, int *x, int *y, int *dist);
void queue_init(queue *q);

#endif
