#include <stdio.h>
#include <stdlib.h>

#include "structures.h"
#include "pQueue.h"
#include "queue.h"

void initialize_pQueue(pQueue *p) {
	//p->head = p->tail = 0;
	p->size = 0; //let's start this array at 1, 0 holds nothing
	//p->array_size = 100;
	//p->heap = malloc(p->array_size * sizeof(pQueue)); //start with 10 slots open

}

void shift_up(pQueue *p, int i) {

	//printf("%i: d", i);
	
	if (i > 1) {
		int parent = i/2;
		//printf("first: %d, sec: %d\n", p->heap[parent].distance, p->heap[i].distance);
		if (p->heap[parent].distance > p->heap[i].distance) {
			int temp = p->heap[parent].distance;
			p->heap[parent].distance = p->heap[i].distance;
			p->heap[i].distance = temp;
			//printf("up %d was switched with %d\n", p->heap[parent].distance, p->heap[i].distance);
			shift_up(p, parent);
		}	
	}
}

void add_pQueue(pQueue *p, int x, int y, int dist) {

	pQueue_node node;
	
	/*
	if (p->size == p->array_size) { //double our heap size when it's full
		p->array_size *= 2;
		p->heap = realloc(p->heap, p->array_size * sizeof(pQueue));
	
	}*/
	
	node.x = x;
	node.y = y;
	node.distance = dist;
	
	p->heap[p->size] = node;
	  
	
	//printf("%d was added\n", dist);
	shift_up(p, p->size);
	p->size++;
}

void shift_down(pQueue *p, int i) {
	int leftPos = i*2 + 1;
	int rightPos = i*2 + 2;
	int minIndex;
	if (rightPos >= p->size) {
		if (leftPos >= p->size) {
			  return;
		}
		else {
			minIndex = leftPos;
		}
	}
	else {
		if (p->heap[leftPos].distance <= p->heap[rightPos].distance) {
			minIndex = leftPos;
		}
		else {
			minIndex = rightPos;
		}
	}
	if (p->heap[i].distance > p->heap[minIndex].distance) {
		//printf("down %d was switched with %d\n", p->heap[minIndex].distance, p->heap[i].distance);
		pQueue_node tmp = p->heap[minIndex];
		p->heap[minIndex] = p->heap[i];
		p->heap[i] = tmp;
		shift_down(p, minIndex);
	}
}

void remove_pQueue(pQueue *p, int *x, int *y, int *dist) {
	//int removed = 0;
	//printf("%d size", p->size);
	if (p->size != 0) {
		*x = p->heap[0].x;
		*y = p->heap[0].y;
		*dist = p->heap[0].distance;
		
		//removed = p->heap[1].distance;
		p->heap[0] = p->heap[p->size-1];
		p->size--;
		if (p->size > 1) {
			//printf("Shifting");
			shift_down(p, 0);
		}	
	}
	//printf("%d, ", removed);
	//return removed;
}

/*
void free_pQueue(pQueue *p) {
	free(p->heap);
	p->heap = NULL;
	p->array_size = p->size = 0;
}*/



/*
int main(int argc, char* argv[]) {
	
	pQueue p;
	int x, y, pry;
	
	initialize_pQueue(&p);
	add_pQueue(&p, 1, 2, 1);
	add_pQueue(&p, 1, 2, 3);
	add_pQueue(&p, 1, 2, 6);
	add_pQueue(&p, 1, 2, 4);
	add_pQueue(&p, 1, 2, 10);
	add_pQueue(&p, 1, 4, 2);
	add_pQueue(&p, 1, 2, 5);
	add_pQueue(&p, 1, 2, 9);
	add_pQueue(&p, 1, 2, 8);
	add_pQueue(&p, 1, 2, 7);
	add_pQueue(&p, 1, 2, 21);
	add_pQueue(&p, 1, 2, 12);
	
	//printf("%d\n", p.heap[0].distance);
	//printf("size: %d, ", p.size);
	
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	//printf("%d was removed from the pQueue\n", remove_pQueue(&p));
	
	while (p.size > 0) {
		remove_pQueue(&p, &x, &y, &pry);
		printf("%d was removed from the pQueue\n", pry);
		//printf("%d, %d, %d", p.heap[1].distance, p.heap[2].distance, p.heap[3].distance);
	}
}

*/



void Dijkstra(dungeon *d, int start_x, int start_y, int goal_x, int goal_y) {

	int dist_traveled = 0;
	
	int current_x = start_x;
	int current_y = start_y;
	
	pQueue q;
	
	initialize_pQueue(&q);
	
	int i,j;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			d->dist_plan[i][j] = 0;
		}
	}
	
	d->dist_plan[current_x][current_y] = 999;
	
	add_pQueue(&q, current_x+1, current_y, 1);
	add_pQueue(&q, current_x-1, current_y, 1);
	add_pQueue(&q, current_x, current_y+1, 1);
	add_pQueue(&q, current_x, current_y-1, 1);
	
	while(q.size != 0) {
		//printf("%d, ", q.size);
		if (current_x == goal_x && current_y == goal_y) {
			break; //because reasons.
		}
		/*
		if (dist_traveled > 160) {
			return; //issue... it can't find anything?
		}*/
		
		if ((current_x < WIDTH-1 || current_x > 1) && (current_y < HEIGHT - 1 || current_y > 1)) {
			remove_pQueue(&q, &current_x, &current_y, &dist_traveled);	
			//printf("true 1 %d %d, ", current_x, current_y);
			//printf("%d  ", d->dist_plan[current_x][current_y]);
			//printf("%d ", d->floor_plan[current_x][current_y]);
			if (d->dist_plan[current_x][current_y] == 0 && d->floor_plan[current_x][current_y] == EMPTY_SPACE) {
				printf("%d ", d->floor_plan[current_x][current_y]);
				if (d->dist_plan[current_x][current_y] != 999) {
					
					d->dist_plan[current_x][current_y] = dist_traveled;
					
					if (current_x < WIDTH-2 && current_x > 2 && current_y < HEIGHT - 2 && current_y > 2) {
						add_pQueue(&q, current_x+1, current_y, dist_traveled+1);
						add_pQueue(&q, current_x-1, current_y, dist_traveled+1);
						add_pQueue(&q, current_x, current_y+1, dist_traveled+1);
						add_pQueue(&q, current_x, current_y-1, dist_traveled+1);
					}
				}
			}
		}		
	}
	
	if (q.size == 0) {
		printf("Uh oh... No path found...");
		return; //well crap.
	}

	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->dist_plan[i][j] == 0) {
				d->dist_plan[i][j] = 999;
			}
		}
	}
	
	
	while(dist_traveled > 2) {
		
		//find which direction leads us back to the start and go that way
		//update the path with a monster_path space!
		d->floor_plan[current_x][current_y] = MONSTER_SPACE;
		printf(" %d ", dist_traveled);
		
		if (d->dist_plan[current_x+1][current_y] < dist_traveled) {
			printf("Right");
			dist_traveled -= 1;
			current_x += 1;
		}
		else if (d->dist_plan[current_x-1][current_y] < dist_traveled) {
			printf("Left");
			dist_traveled -= 1;
			current_x -= 1;
		}
		else if (d->dist_plan[current_x][current_y+1] < dist_traveled) {
			printf("Down");
			dist_traveled -= 1;
			current_y += 1;
		}
		else if (d->dist_plan[current_x][current_y-1] < dist_traveled) {
			printf("Up");
			dist_traveled -= 1;
			current_y -= 1;
		}
		else {
			printf("help");
		}	
	}
	//d->floor_plan[current_x][current_y] = MONSTER_SPACE;
	
	while (q.size != 1) {
		remove_pQueue(&q, &current_x, &current_y, &dist_traveled);
	}
	//free_pQueue(&q);
	
	
}

square bad_Dijkstra(dungeon *d, int start_x, int start_y, int goal_x, int goal_y) {

	int dist_traveled = 0;
	
	int current_x = start_x;
	int current_y = start_y;
	
	queue q;
	
	queue_init(&q);
	
	int i,j;
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			d->dist_plan[i][j] = 0;
		}
	}
	
	d->dist_plan[current_x][current_y] = 999;
	
	queue_add(&q, current_x+1, current_y, 1);
	queue_add(&q, current_x-1, current_y, 1);
	queue_add(&q, current_x, current_y+1, 1);
	queue_add(&q, current_x, current_y-1, 1);
	
	while(q.size != 0) {
		//printf("%d, ", q.size);
		if (current_x == goal_x && current_y == goal_y) {
			//printf("Path found ");
			break; //because reasons.
		}
		
		
		
		if ((current_x < WIDTH-1 || current_x > 1) && (current_y < HEIGHT - 1 || current_y > 1)) {
			queue_remove(&q, &current_x, &current_y, &dist_traveled);	
			//printf("true 1 %d %d, ", current_x, current_y);
			//printf("%d  ", d->dist_plan[current_x][current_y]);
			//printf("%d ", d->floor_plan[current_x][current_y]);
			if (d->dist_plan[current_x][current_y] == 0 && (d->floor_plan[current_x][current_y] == EMPTY_SPACE || d->floor_plan[current_x][current_y] == MONSTER_SPACE)) {
				//printf("%d ", d->floor_plan[current_x][current_y]);
				if (d->dist_plan[current_x][current_y] != 999) {
					
					d->dist_plan[current_x][current_y] = dist_traveled;
					
					if (current_x < WIDTH-2 && current_x > 2 && current_y < HEIGHT - 2 && current_y > 2) {
						queue_add(&q, current_x+1, current_y, dist_traveled+1);
						queue_add(&q, current_x-1, current_y, dist_traveled+1);
						queue_add(&q, current_x, current_y+1, dist_traveled+1);
						queue_add(&q, current_x, current_y-1, dist_traveled+1);
					}
				}
			}
		}		
	}
	
	if (q.size == 0) {
		//printf("Uh oh... No path found...");
		//square crap = {start_x, start_y};
		//return crap; //well crap.
	}

	//printf("Path found\n");
	
	for (j = 0; j < HEIGHT; j++) {
		for (i = 0; i < WIDTH; i++) {
			if (d->dist_plan[i][j] == 0) {
				d->dist_plan[i][j] = 999;
			}
		}
	}
	
	
	while(dist_traveled > 1) {
		
		//find which direction leads us back to the start and go that way
		//update the path with a monster_path space!
		//d->floor_plan[current_x][current_y] = MONSTER_SPACE;
		//printf(" %d ", dist_traveled);
		
		if (d->dist_plan[current_x+1][current_y] < dist_traveled) {
			//printf("Right");
			dist_traveled -= 1;
			current_x += 1;
		}
		else if (d->dist_plan[current_x-1][current_y] < dist_traveled) {
			//printf("Left");
			dist_traveled -= 1;
			current_x -= 1;
		}
		else if (d->dist_plan[current_x][current_y+1] < dist_traveled) {
			//printf("Down");
			dist_traveled -= 1;
			current_y += 1;
		}
		else if (d->dist_plan[current_x][current_y-1] < dist_traveled) {
			//printf("Up");
			dist_traveled -= 1;
			current_y -= 1;
		}
		else {
			printf("help");
		}	
	}
	
	//d->floor_plan[current_x][current_y] = MONSTER_SPACE;
	
	square next = {current_x, current_y};
	
	while (q.size != 0) {
		queue_remove(&q, &current_x, &current_y, &dist_traveled);
	}
	
	return next;
}


  