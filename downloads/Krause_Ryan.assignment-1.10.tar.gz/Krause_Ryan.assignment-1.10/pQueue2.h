#ifndef PQUEUE2_H
#define PQUEUE2_H

#include "structures.h"

typedef struct pQueue_node2 {
  character ch;
  int priority;
} pQueue_node2;

typedef struct pQueue2 {
  //queue_node *head, *tail;
  pQueue_node2 heap[100];
  int array_size; //space for elements
  int size; //used elements
} pQueue2;

void initialize_pQueue2(pQueue2 *p);
void shift_up2(pQueue2 *p, int i);
void add_pQueue2(pQueue2 *p, character ch);
void shift_down2(pQueue2 *p, int i);
void remove_pQueue2(pQueue2 *p, character *ch);
void free_pQueue2(pQueue2 *p);

#endif
