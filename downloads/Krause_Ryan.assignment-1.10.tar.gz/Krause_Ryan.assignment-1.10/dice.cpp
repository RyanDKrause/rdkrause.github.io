#include <cstdlib>

#include "dice.h"
#include "structures.h"

int roll(const dice &d) {
	int total = 0;
	int i;
	
	total += d.get_base();
	
	if (d.get_sides()) { //make sure that our dice rolling has sides to ROLL
		for (i = 0; i < d.get_number(); i++) { //if we have no die, then we don't go here anyway
			total+= rand() % d.get_sides() + 1;
		}
	}
	return total;
}

dice_c convert_to_c(const dice &d) {
	dice_c temp;
	temp.base = d.get_base();
	temp.num_dices = d.get_number();
	temp.sides = d.get_sides();
	return temp;
}