#ifndef CREATE_H
#define CREATE_H

#include "structures.h"

int low_roll(dice_c d);
int high_roll(dice_c d);
int roll_damage(dice_c dice);

void initialize_dungeon(dungeon *d);
void add_room(dungeon *d);
void print_dungeon(dungeon *d);
void update_rocks(dungeon *d);
void update_hardness(dungeon *d);
void create_dungeon(dungeon *d);
void BFS(dungeon *d, int room_number);
void add_stairs(dungeon *d);
void free_characters_and_inventory(dungeon *d);


#endif
