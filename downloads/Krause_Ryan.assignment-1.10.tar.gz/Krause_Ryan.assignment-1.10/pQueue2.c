#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "structures.h"
#include "pQueue2.h"

void initialize_pQueue2(pQueue2 *p) {
	p->size = 0; //let's start this array at 1, 0 holds nothing

}

void shift_up2(pQueue2 *p, int i) {
	
	if (i >= 1) {
		int parent = i/2;
		if (p->heap[parent].priority > p->heap[i].priority) {
			pQueue_node2 temp = p->heap[parent];
			p->heap[parent] = p->heap[i];
			p->heap[i] = temp;
			shift_up2(p, parent);
		}	
	}
}

void add_pQueue2(pQueue2 *p, character ch) {

	pQueue_node2 node;
	
	/*
	if (p->size == p->array_size) { //double our heap size when it's full
		p->array_size *= 2;
		p->heap = realloc(p->heap, p->array_size * sizeof(pQueue));
	
	}*/
	
	node.ch = ch;
	node.priority = ch.next_turn;
	
	//printf("Added priority: %d\n", node.priority);
	
	p->heap[p->size] = node;
	  
	
	shift_up2(p, p->size);
	p->size++;
}

void shift_down2(pQueue2 *p, int i) {
	int leftPos = i*2 + 1;
	int rightPos = i*2 + 2;
	int minIndex;
	if (rightPos >= p->size) {
		if (leftPos >= p->size) {
			  return;
		}
		else {
			minIndex = leftPos;
		}
	}
	else {
		if (p->heap[leftPos].priority <= p->heap[rightPos].priority) {
			minIndex = leftPos;
		}
		else {
			minIndex = rightPos;
		}
	}
	if (p->heap[i].priority > p->heap[minIndex].priority) {
		pQueue_node2 tmp = p->heap[minIndex];
		p->heap[minIndex] = p->heap[i];
		p->heap[i] = tmp;
		shift_down2(p, minIndex);
	}
}

void remove_pQueue2(pQueue2 *p, character *ch) {
	if (p->size != 0) {
		*ch = p->heap[0].ch;
		
		//printf("Removed priority: %d\n", p->heap[0].priority);

		p->heap[0] = p->heap[p->size-1];
		p->size--;
		if (p->size >= 1) {
			shift_down2(p, 0);
		}	
	}
}

