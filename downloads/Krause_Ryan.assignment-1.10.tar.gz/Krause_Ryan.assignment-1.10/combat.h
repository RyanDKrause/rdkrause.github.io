#ifndef COMBAT_H
#define COMBAT_H

#include "structures.h"

int monster_battle(dungeon *d, int monster_id);
int player_battle(dungeon *d, int monster_id);
int calculate_speed(dungeon *d);

#endif
