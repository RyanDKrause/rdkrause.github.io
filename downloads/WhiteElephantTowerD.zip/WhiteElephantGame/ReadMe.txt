Hi everyone, I'm Ryan Krause

This game was made in 48 hours as part of a competition, so don't hold me too much to this.

Due to lack of time, this game remains incredibly unbalanced. In my eyes, if you can make it past the first wave, you win.

As we don't have an instruction screen, this will have to do: 

The majority of the game is point and click.
The four units:
Top Left (Tranq Man): Shoots a basic tranquilizer at an elephants.
Top Right (Missile Man): Shoots an explosion at an elephant, deals splash damage to surrouding elephants.
Bottom Left (Peanut Mech): Shoots a peanut at an elephant, thus reducing their speed for a short time.
Bottom Right (Mouse Man): Releases a mouse at an elephant, thus temporarily scaring the elephant back.

All units can be upgrades to rank 4, starting at rank 0.
Units can also be sold for a full refund.

There are 10 waves, so do your best! Watch out for that slow boss at wave 10...

Tip: Upgrading one turret twice can usually be better than buying a new turret...

Game still too hard? Press 9. Have fun!

I hope you enjoy playing this short game as much as I did programming it!


*Made in Game Maker Studio Pro*